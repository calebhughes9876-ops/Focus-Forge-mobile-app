import {
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
} from "react-native";
import { useEffect, useRef, useState } from "react";
import { useRouter } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useAuthContext } from "@/lib/auth-context";
import { FocusForgeData, loadFocusData } from "@/lib/focus-data";

interface Message {
  id: string;
  type: "ai" | "user";
  text: string;
}

function buildCoachReply(input: string, data: FocusForgeData | null) {
  const lower = input.toLowerCase();
  const streak = data?.streak ?? 0;
  const pendingMissions = data?.missions.filter((mission) => !mission.completedToday).length ?? 0;
  const score = data?.focusScoreAverage ?? 0;

  if (lower.includes("distract") || lower.includes("scroll")) {
    return `Then close the escape hatch. Pick a stricter shield preset, finish one ${pendingMissions > 0 ? "pending mission" : "25 minute sprint"}, and report back with the result.`;
  }

  if (lower.includes("miss") || lower.includes("failed")) {
    return `You missed a rep, not the whole program. Protect one short session today, recover the streak tomorrow, and stop negotiating with your phone.`;
  }

  if (lower.includes("motivat")) {
    return `Motivation is weak leverage. Systems win. Your current streak is ${streak} and your focus score is ${score}; raise both by finishing the next session before you ask for another pep talk.`;
  }

  if (lower.includes("plan") || lower.includes("today")) {
    return `Plan less, commit more. Choose one hard mission, one support mission, then lock in a 25 or 50 minute block and start immediately.`;
  }

  return `Good. Keep it concrete. You have ${pendingMissions} mission${pendingMissions === 1 ? "" : "s"} left today, so name the next one and attach a timer to it right now.`;
}

export default function CoachScreen() {
  const colors = useColors();
  const router = useRouter();
  const { isPremium, user } = useAuthContext();
  const scrollRef = useRef<ScrollView>(null);

  const [data, setData] = useState<FocusForgeData | null>(null);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      type: "ai",
      text: "You showed up. Good. Tell me the mission that matters most today and the exact session length you’re going to protect for it.",
    },
  ]);
  const [inputText, setInputText] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    async function loadCoachContext() {
      if (!user) return;
      const stored = await loadFocusData(String(user.id));
      setData(stored);
    }

    loadCoachContext().catch((error) => console.log("Coach context error:", error));
  }, [user]);

  const quickResponses = [
    "I completed my session",
    "I missed yesterday",
    "I got distracted",
    "Help me plan today",
    "Push me harder",
  ];

  const handleSend = async (text: string) => {
    if (!text.trim() || isLoading) return;

    const userMsg: Message = {
      id: String(Date.now()),
      type: "user",
      text: text.trim(),
    };

    setMessages((previous) => [...previous, userMsg]);
    setInputText("");
    setIsLoading(true);
    setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 100);

    const replyText = buildCoachReply(text.trim(), data);

    setTimeout(() => {
      const aiMsg: Message = {
        id: String(Date.now() + 1),
        type: "ai",
        text: replyText,
      };

      setMessages((previous) => [...previous, aiMsg]);
      setIsLoading(false);
      setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 100);
    }, 500);
  };

  if (!isPremium) {
    return (
      <ScreenContainer className="items-center justify-center p-4">
        <ScrollView showsVerticalScrollIndicator={false} className="flex-1">
          <View className="gap-6 items-center py-8">
            <Text className="text-3xl font-bold text-foreground text-center">
              Unlock the Accountability Coach
            </Text>
            <Text className="text-muted text-center leading-relaxed">
              Competing focus apps monetize by putting stronger commitment systems behind
              premium. FocusForge Pro now does the same with coach pressure, deeper shield
              modes, advanced analytics, and circles.
            </Text>

            <View className="bg-surface rounded-2xl p-4 w-full gap-3">
              <Text className="text-sm font-bold text-foreground">Pro Features</Text>
              <View className="gap-2">
                <Text className="text-muted text-sm">• Daily accountability check-ins</Text>
                <Text className="text-muted text-sm">• Deep Focus Shield and Monk Mode</Text>
                <Text className="text-muted text-sm">• Weekly review reflections</Text>
                <Text className="text-muted text-sm">• Focus circles and premium leagues</Text>
                <Text className="text-muted text-sm">• Advanced focus score analytics</Text>
              </View>
            </View>

            <TouchableOpacity
              onPress={() => router.push("/premium")}
              activeOpacity={0.8}
              style={{ backgroundColor: colors.primary }}
              className="w-full rounded-full py-4 items-center"
            >
              <Text className="text-background font-bold text-lg">See Pro Plans</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer>
      <KeyboardAvoidingView
        className="flex-1"
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        keyboardVerticalOffset={90}
      >
        <View className="flex-1 p-4 gap-4">
          <View className="gap-1">
            <Text className="text-3xl font-bold text-foreground">AI Coach</Text>
            <Text className="text-muted text-sm">
              Personalized accountability built from your streak, missions, and session history.
            </Text>
          </View>

          <View className="bg-primary/10 border border-primary rounded-2xl p-4 gap-2">
            <Text className="text-primary text-xs font-bold uppercase tracking-wide">
              Current Snapshot
            </Text>
            <Text className="text-foreground font-semibold">
              Streak {data?.streak ?? 0} • Score {data?.focusScoreAverage ?? 0} • Pending
              missions {data?.missions.filter((mission) => !mission.completedToday).length ?? 0}
            </Text>
          </View>

          <ScrollView
            ref={scrollRef}
            className="flex-1 bg-surface rounded-2xl p-4"
            showsVerticalScrollIndicator={false}
          >
            <View className="gap-3">
              {messages.map((msg) => (
                <View
                  key={msg.id}
                  className={`flex-row ${msg.type === "ai" ? "justify-start" : "justify-end"}`}
                >
                  <View
                    className={`rounded-2xl p-3 ${
                      msg.type === "ai"
                        ? "bg-background border border-border max-w-xs"
                        : "bg-primary max-w-xs"
                    }`}
                  >
                    <Text className={msg.type === "ai" ? "text-foreground" : "text-background"}>
                      {msg.text}
                    </Text>
                  </View>
                </View>
              ))}

              {isLoading && (
                <View className="flex-row justify-start">
                  <View className="bg-background border border-border rounded-2xl p-3 flex-row gap-2 items-center">
                    <ActivityIndicator size="small" color={colors.primary} />
                    <Text className="text-muted text-sm">Coach is lining up your next move...</Text>
                  </View>
                </View>
              )}
            </View>
          </ScrollView>

          <View className="gap-2">
            <Text className="text-xs text-muted font-bold">Quick prompts</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              <View className="flex-row gap-2">
                {quickResponses.map((response) => (
                  <TouchableOpacity
                    key={response}
                    onPress={() => handleSend(response)}
                    disabled={isLoading}
                    activeOpacity={0.7}
                    className="bg-surface border border-primary rounded-2xl px-3 py-2"
                  >
                    <Text className="text-foreground text-xs font-medium">{response}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </ScrollView>
          </View>

          <View className="flex-row gap-2 items-center">
            <TextInput
              value={inputText}
              onChangeText={setInputText}
              placeholder="Type your response..."
              placeholderTextColor={colors.muted}
              className="flex-1 bg-surface rounded-2xl px-4 py-3 text-foreground"
              onSubmitEditing={() => handleSend(inputText)}
              returnKeyType="send"
              editable={!isLoading}
            />
            <TouchableOpacity
              onPress={() => handleSend(inputText)}
              disabled={isLoading || !inputText.trim()}
              activeOpacity={0.8}
              style={{
                backgroundColor: isLoading || !inputText.trim() ? colors.muted : colors.primary,
              }}
              className="rounded-2xl px-4 py-3"
            >
              <Text className="text-background font-bold">Send</Text>
            </TouchableOpacity>
          </View>
        </View>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

import { Text, View, TouchableOpacity, Alert, TextInput } from "react-native";
import { useEffect, useRef, useState } from "react";
import { useLocalSearchParams, useRouter } from "expo-router";
import * as Haptics from "expo-haptics";
import { useKeepAwake } from "expo-keep-awake";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useAuthContext } from "@/lib/auth-context";
import {
  FocusForgeData,
  MoodTag,
  applyCompletedSession,
  buildSessionRecord,
  getActiveShieldPreset,
  loadFocusData,
  saveFocusData,
} from "@/lib/focus-data";
import { disableAppBlocking, enableAppBlocking } from "@/lib/app-blocking-service";

interface FocusSessionPreset {
  duration: number;
  label: string;
  xpReward: number;
}

const MOOD_OPTIONS: MoodTag[] = ["locked-in", "steady", "distracted", "burned-out"];

export default function FocusModeScreen() {
  const colors = useColors();
  const router = useRouter();
  const { user } = useAuthContext();
  const { duration: paramDuration, missionId, shieldPresetId } = useLocalSearchParams();

  useKeepAwake();

  const focusLevels: Record<number, FocusSessionPreset> = {
    15: { duration: 15, label: "Reset Sprint", xpReward: 20 },
    25: { duration: 25, label: "Core Focus", xpReward: 45 },
    50: { duration: 50, label: "Deep Forge", xpReward: 95 },
    90: { duration: 90, label: "Monk Session", xpReward: 160 },
  };

  const selectedDuration = Number.parseInt(String(paramDuration), 10) || 25;
  const session = focusLevels[selectedDuration] ?? focusLevels[25];

  const [timeLeft, setTimeLeft] = useState(selectedDuration * 60);
  const [isRunning, setIsRunning] = useState(true);
  const [isCompleted, setIsCompleted] = useState(false);
  const [data, setData] = useState<FocusForgeData | null>(null);
  const [reflection, setReflection] = useState("");
  const [mood, setMood] = useState<MoodTag>("locked-in");
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    async function initializeSession() {
      if (!user) return;

      const loaded = await loadFocusData(String(user.id));
      setData(loaded);
      await enableAppBlocking(selectedDuration);
    }

    initializeSession();

    return () => {
      disableAppBlocking().catch((error) => console.log("Shield cleanup error:", error));
    };
  }, [selectedDuration, user]);

  useEffect(() => {
    if (!isRunning || isCompleted) return;

    intervalRef.current = setInterval(() => {
      setTimeLeft((previous) => {
        if (previous <= 1) {
          setIsRunning(false);
          setIsCompleted(true);
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          return 0;
        }

        return previous - 1;
      });
    }, 1000);

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [isCompleted, isRunning]);

  const mission =
    data?.missions.find((item) => item.id === String(missionId)) ??
    data?.missions.find((item) => !item.completedToday) ??
    null;
  const activeShield =
    (data?.shieldPresets?.find((preset) => preset.id === String(shieldPresetId))) ??
    (data ? getActiveShieldPreset(data) : null);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
  };

  const handlePause = async () => {
    setIsRunning((current) => !current);
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const handleEmergencyExit = () => {
    Alert.alert("Exit Focus?", "Your streak will reset and this mission will count as missed.", [
      { text: "Stay Locked In", onPress: () => {} },
      {
        text: "Exit Anyway",
        style: "destructive",
        onPress: async () => {
          await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
          if (user && data) {
            const updated: FocusForgeData = {
              ...data,
              streak: 0,
              missions: data.missions.map((item) =>
                item.id === mission?.id ? { ...item, status: "missed", completedToday: false } : item
              ),
            };
            await saveFocusData(String(user.id), updated);
          }
          await disableAppBlocking();
          router.back();
        },
      },
    ]);
  };

  const handleComplete = async () => {
    if (!user || !data) {
      Alert.alert("Error", "User data is unavailable.");
      return;
    }

    const interruptionsAvoided = activeShield && activeShield.apps
      ? activeShield.apps.filter((app) => app.blocked).length
      : 3;

    const sessionRecord = buildSessionRecord({
      duration: session.duration,
      xpEarned: session.xpReward + (mission?.xpReward ?? 0),
      label: session.label,
      missionId: mission?.id ?? null,
      missionTitle: mission?.title ?? null,
      mood,
      reflection: reflection.trim(),
      shieldPresetId: activeShield?.id ?? null,
      interruptionsAvoided,
    });

    const updated = applyCompletedSession(data, sessionRecord);
    await saveFocusData(String(user.id), updated);
    await disableAppBlocking();
    router.back();
  };

  const progress = ((selectedDuration * 60 - timeLeft) / (selectedDuration * 60)) * 100;

  if (isCompleted) {
    return (
      <ScreenContainer className="items-center justify-center p-4">
        <View className="gap-5 items-center w-full">
          <Text className="text-5xl font-bold text-foreground text-center">Session Complete</Text>
          <Text className="text-muted text-center">
            You protected {session.duration} minutes and pushed another brick into the wall.
          </Text>

          <View className="bg-surface rounded-2xl p-5 w-full gap-3">
            <View className="flex-row justify-between">
              <Text className="text-muted">Session</Text>
              <Text className="text-foreground font-bold">{session.label}</Text>
            </View>
            <View className="flex-row justify-between">
              <Text className="text-muted">Mission</Text>
              <Text className="text-foreground font-bold">
                {mission?.title ?? "Unassigned sprint"}
              </Text>
            </View>
            <View className="flex-row justify-between">
              <Text className="text-muted">Shield</Text>
              <Text className="text-foreground font-bold">{activeShield?.name ?? "Standard"}</Text>
            </View>
            <View className="flex-row justify-between">
              <Text className="text-muted">XP Earned</Text>
              <Text className="text-primary font-bold">
                +{session.xpReward + (mission?.xpReward ?? 0)} XP
              </Text>
            </View>
          </View>

          <View className="w-full gap-2">
            <Text className="text-sm font-bold text-foreground">How did the session feel?</Text>
            <View className="flex-row gap-2 flex-wrap">
              {MOOD_OPTIONS.map((option) => (
                <TouchableOpacity
                  key={option}
                  onPress={() => setMood(option)}
                  className={`rounded-full px-4 py-2 border ${
                    mood === option ? "bg-primary border-primary" : "bg-surface border-border"
                  }`}
                >
                  <Text className={mood === option ? "text-background font-bold" : "text-foreground"}>
                    {option}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          <View className="w-full gap-2">
            <Text className="text-sm font-bold text-foreground">
              Quick reflection for your weekly review
            </Text>
            <TextInput
              value={reflection}
              onChangeText={setReflection}
              placeholder="What helped you stay focused?"
              placeholderTextColor={colors.muted}
              multiline
              className="bg-surface rounded-2xl p-4 min-h-28 text-foreground"
            />
          </View>

          <TouchableOpacity
            onPress={handleComplete}
            activeOpacity={0.8}
            style={{ backgroundColor: colors.primary }}
            className="w-full rounded-full py-4 items-center"
          >
            <Text className="text-background font-bold text-lg">Save Session</Text>
          </TouchableOpacity>
        </View>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer className="items-center justify-center p-4">
      <View className="flex-1 w-full items-center justify-center gap-8">
        <View className="items-center gap-2">
          <Text className="text-muted text-sm font-bold uppercase tracking-widest">
            {session.label}
          </Text>
          <Text className="text-muted text-xs">
            {mission ? `Mission: ${mission.title}` : "No mission linked"}
          </Text>
          <Text className="text-primary text-xs font-semibold">
            Shield: {activeShield?.name ?? "Balanced Shield"}
          </Text>
        </View>

        <View className="relative items-center justify-center w-72 h-72">
          <View className="absolute w-full h-full rounded-full border-8 border-surface" />
          <View
            className="absolute w-full h-full rounded-full border-8 border-primary"
            style={{ opacity: progress / 100 }}
          />
          <View className="items-center gap-2">
            <Text className="text-7xl font-bold text-primary">{formatTime(timeLeft)}</Text>
            <Text className="text-muted text-sm">{session.duration} minute commitment</Text>
          </View>
        </View>

        <View className="bg-surface rounded-2xl p-4 gap-3 w-full">
          <View className="flex-row justify-between">
            <Text className="text-muted text-sm">Shield mode</Text>
            <Text className="text-foreground font-semibold">{activeShield?.mode ?? "balanced"}</Text>
          </View>
          <View className="flex-row justify-between">
            <Text className="text-muted text-sm">Blocked distractions</Text>
            <Text className="text-foreground font-semibold">
              {activeShield?.apps?.filter((app) => app.blocked).length ?? 0}
            </Text>
          </View>
          <View className="flex-row justify-between">
            <Text className="text-muted text-sm">XP on completion</Text>
            <Text className="text-primary font-semibold">
              +{session.xpReward + (mission?.xpReward ?? 0)}
            </Text>
          </View>
        </View>

        <View className="flex-row gap-4 w-full justify-center">
          <TouchableOpacity
            onPress={handlePause}
            activeOpacity={0.7}
            className="bg-surface rounded-full px-8 py-3"
          >
            <Text className="text-foreground font-bold">{isRunning ? "Pause" : "Resume"}</Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={handleEmergencyExit}
            activeOpacity={0.7}
            className="bg-error/20 rounded-full px-8 py-3"
          >
            <Text className="text-error font-bold">Emergency Exit</Text>
          </TouchableOpacity>
        </View>

        <View className="bg-error/10 border border-error rounded-2xl p-3 w-full">
          <Text className="text-error text-xs text-center font-semibold">
            Premium-style deep focus is strongest when you finish without pausing or exiting.
          </Text>
        </View>
      </View>
    </ScreenContainer>
  );
}

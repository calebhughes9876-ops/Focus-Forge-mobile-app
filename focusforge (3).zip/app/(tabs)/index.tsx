import { Text, View, ScrollView, TouchableOpacity, ActivityIndicator } from "react-native";
import { useCallback, useMemo, useState } from "react";
import { useFocusEffect, useRouter } from "expo-router";
import * as Haptics from "expo-haptics";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useAuthContext } from "@/lib/auth-context";
import {
  FocusForgeData,
  calculateMissionCompletionRate,
  calculateTodayFocusMinutes,
  getActiveShieldPreset,
  loadFocusData,
} from "@/lib/focus-data";

interface FocusCard {
  duration: number;
  label: string;
  sublabel: string;
  xpReward: number;
  unlocked: boolean;
  difficulty: string;
}

export default function HomeScreen() {
  const colors = useColors();
  const router = useRouter();
  const { user, isPremium } = useAuthContext();
  const [data, setData] = useState<FocusForgeData | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedMissionId, setSelectedMissionId] = useState<string | null>(null);

  const loadData = useCallback(async () => {
    if (!user) {
      setLoading(false);
      return;
    }

    setLoading(true);
    try {
      const stored = await loadFocusData(user.id);
      setData(stored);

      const selectedMission = stored.missions.find((mission) => mission.id === selectedMissionId);
      if (!selectedMissionId || selectedMission?.completedToday) {
        const firstPendingMission = stored.missions.find((mission) => !mission.completedToday);
        setSelectedMissionId(firstPendingMission?.id ?? null);
      }
    } catch (error) {
      console.log("Error loading data:", error);
    } finally {
      setLoading(false);
    }
  }, [selectedMissionId, user]);

  useFocusEffect(
    useCallback(() => {
      loadData();
    }, [loadData])
  );

  const focusCards: FocusCard[] = useMemo(() => {
    const completedSessions = data?.completedSessions ?? 0;
    const streak = data?.streak ?? 0;

    return [
      {
        duration: 15,
        label: "Reset Sprint",
        sublabel: "Recover momentum fast",
        xpReward: 20,
        unlocked: true,
        difficulty: "Easy",
      },
      {
        duration: 25,
        label: "Core Focus",
        sublabel: "Best for daily consistency",
        xpReward: 45,
        unlocked: true,
        difficulty: "Normal",
      },
      {
        duration: 50,
        label: "Deep Forge",
        sublabel: "Single-task hard mode",
        xpReward: 95,
        unlocked: completedSessions >= 4,
        difficulty: "Hard",
      },
      {
        duration: 90,
        label: "Monk Session",
        sublabel: "High stakes output block",
        xpReward: 160,
        unlocked: streak >= 7 || isPremium,
        difficulty: "Elite",
      },
    ];
  }, [data?.completedSessions, data?.streak, isPremium]);

  const selectedMission =
    data?.missions.find((mission) => mission.id === selectedMissionId) ??
    data?.missions.find((mission) => !mission.completedToday) ??
    null;
  const activeShield = data ? getActiveShieldPreset(data) : null;
  const todayFocusMinutes = calculateTodayFocusMinutes(data?.sessionHistory ?? []);
  const missionCompletionRate = calculateMissionCompletionRate(data?.missions ?? []);

  const handleStartFocus = async (duration: number) => {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    router.push({
      pathname: "./focus-mode",
      params: {
        duration: String(duration),
        missionId: selectedMission?.id ?? "",
        shieldPresetId: activeShield?.id ?? "",
      },
    });
  };

  if (loading) {
    return (
      <ScreenContainer className="items-center justify-center">
        <ActivityIndicator size="large" color={colors.primary} />
      </ScreenContainer>
    );
  }

  if (!data) {
    return (
      <ScreenContainer className="items-center justify-center p-6">
        <Text className="text-foreground text-lg font-semibold text-center">
          Sign in to load your FocusForge dashboard.
        </Text>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer>
      <ScrollView showsVerticalScrollIndicator={false} className="flex-1">
        <View className="p-4 gap-6 pb-8">
          <View className="gap-2.5">
            <View className="flex-row items-center justify-between">
              <View className="gap-1">
                <Text className="text-5xl font-bold text-foreground tracking-tight">
                  FocusForge
                </Text>
                <Text className="text-muted text-sm leading-relaxed">
                  Hard focus. Fewer escape hatches. Better output.
                </Text>
              </View>
              {isPremium ? (
                <View className="bg-primary/15 rounded-full px-3 py-2">
                  <Text className="text-primary text-xs font-bold uppercase tracking-wide">
                    Pro Active
                  </Text>
                </View>
              ) : (
                <TouchableOpacity
                  onPress={() => router.push("/premium")}
                  className="bg-surface border border-primary rounded-full px-3 py-2"
                >
                  <Text className="text-primary text-xs font-bold uppercase tracking-wide">
                    Upgrade
                  </Text>
                </TouchableOpacity>
              )}
            </View>
          </View>

          <View className="flex-row gap-3">
            <View className="flex-1 bg-surface rounded-2xl p-4 gap-1.5">
              <Text className="text-muted text-xs font-semibold uppercase tracking-wide">
                Streak
              </Text>
              <Text className="text-3xl font-bold text-primary">{data.streak} days</Text>
            </View>
            <View className="flex-1 bg-surface rounded-2xl p-4 gap-1.5">
              <Text className="text-muted text-xs font-semibold uppercase tracking-wide">
                Focus Today
              </Text>
              <Text className="text-3xl font-bold text-foreground">{todayFocusMinutes}m</Text>
            </View>
            <View className="flex-1 bg-surface rounded-2xl p-4 gap-1.5">
              <Text className="text-muted text-xs font-semibold uppercase tracking-wide">
                Score
              </Text>
              <Text className="text-3xl font-bold text-success">{data.focusScoreAverage || 0}</Text>
            </View>
          </View>

          <View className="bg-surface rounded-2xl p-5 gap-4 border border-border">
            <View className="flex-row items-start justify-between gap-4">
              <View className="flex-1 gap-1">
                <Text className="text-xs font-bold text-muted uppercase tracking-wide">
                  Today&apos;s Missions
                </Text>
                <Text className="text-2xl font-bold text-foreground">
                  {missionCompletionRate}% complete
                </Text>
                <Text className="text-muted text-sm">
                  Focus To-Do style mission planning, but with stricter accountability.
                </Text>
              </View>
              <TouchableOpacity
                onPress={() => router.push("/missions")}
                className="rounded-full px-4 py-2 border border-primary"
              >
                <Text className="text-primary font-semibold">Plan</Text>
              </TouchableOpacity>
            </View>

            <View className="gap-3">
              {data.missions.map((mission) => {
                const selected = selectedMissionId === mission.id;
                return (
                  <TouchableOpacity
                    key={mission.id}
                    onPress={() => setSelectedMissionId(mission.id)}
                    activeOpacity={0.8}
                    className={`rounded-2xl p-4 border ${
                      mission.completedToday
                        ? "bg-success/10 border-success"
                        : selected
                          ? "bg-primary/10 border-primary"
                          : "bg-background border-border"
                    }`}
                  >
                    <View className="flex-row items-center justify-between gap-3">
                      <View className="flex-1 gap-1">
                        <Text className="text-foreground font-bold">{mission.title}</Text>
                        <Text className="text-muted text-xs">
                          {mission.category} • {mission.minutesTarget} min • due{" "}
                          {String(mission.dueHour).padStart(2, "0")}:
                          {String(mission.dueMinute).padStart(2, "0")}
                        </Text>
                        <Text className="text-muted text-xs">{mission.note}</Text>
                      </View>
                      <View className="items-end gap-2">
                        <View className="bg-primary/15 rounded-full px-3 py-1">
                          <Text className="text-primary text-xs font-bold">
                            +{mission.xpReward} XP
                          </Text>
                        </View>
                        <Text
                          className={`text-xs font-bold ${
                            mission.completedToday ? "text-success" : "text-muted"
                          }`}
                        >
                          {mission.completedToday ? "Done" : selected ? "Selected" : "Pending"}
                        </Text>
                      </View>
                    </View>
                  </TouchableOpacity>
                );
              })}
            </View>
          </View>

          <View className="bg-primary/10 border border-primary rounded-2xl p-5 gap-3">
            <View className="flex-row items-center justify-between gap-4">
              <View className="flex-1 gap-1">
                <Text className="text-xs font-bold text-primary uppercase tracking-wide">
                  Focus Shield
                </Text>
                <Text className="text-xl font-bold text-foreground">{activeShield?.name}</Text>
                <Text className="text-muted text-sm">
                  {activeShield?.description}
                </Text>
              </View>
              <TouchableOpacity
                onPress={() => router.push("/shield")}
                className="rounded-full px-4 py-2 bg-primary"
              >
                <Text className="text-background font-bold">Manage</Text>
              </TouchableOpacity>
            </View>

            <View className="flex-row gap-2 flex-wrap">
              <View className="bg-background rounded-full px-3 py-2">
                <Text className="text-foreground text-xs font-semibold">
                  {(activeShield?.mode ?? "balanced").toUpperCase()} mode
                </Text>
              </View>
              <View className="bg-background rounded-full px-3 py-2">
                <Text className="text-foreground text-xs font-semibold">
                  {(activeShield?.listMode === "allowlist") ? "Allowlist" : "Blocklist"}
                </Text>
              </View>
              <View className="bg-background rounded-full px-3 py-2">
                <Text className="text-foreground text-xs font-semibold">
                  {(activeShield?.allowBreaks ?? false) ? "Breaks on" : "No breaks"}
                </Text>
              </View>
            </View>
          </View>

          <View className="gap-4">
            <Text className="text-xl font-bold text-foreground tracking-tight">
              Start a Session
            </Text>

            {focusCards.map((card) => (
              <TouchableOpacity
                key={card.duration}
                onPress={() => card.unlocked && handleStartFocus(card.duration)}
                activeOpacity={card.unlocked ? 0.75 : 1}
                disabled={!card.unlocked}
                className={`rounded-2xl p-5 border-2 ${
                  card.unlocked
                    ? "bg-surface border-primary"
                    : "bg-surface/50 border-border opacity-50"
                }`}
              >
                <View className="flex-row items-center justify-between">
                  <View className="flex-1 gap-2">
                    <Text className="text-4xl font-bold text-primary tracking-tight">
                      {card.duration} MIN
                    </Text>
                    <View className="gap-1">
                      <Text className="text-foreground font-semibold">{card.label}</Text>
                      <Text className="text-muted text-xs">{card.sublabel}</Text>
                      {selectedMission && (
                        <Text className="text-muted text-xs">
                          Linked mission: {selectedMission.title}
                        </Text>
                      )}
                    </View>
                    <View className="flex-row gap-2 mt-1">
                      <View className="bg-primary/20 rounded-lg px-2.5 py-1.5">
                        <Text className="text-primary text-xs font-bold">{card.difficulty}</Text>
                      </View>
                      <View className="bg-success/20 rounded-lg px-2.5 py-1.5">
                        <Text className="text-success text-xs font-bold">+{card.xpReward} XP</Text>
                      </View>
                    </View>
                  </View>
                  {!card.unlocked && (
                    <View className="items-center gap-1">
                      <Text className="text-3xl">Locked</Text>
                      <Text className="text-muted text-xs font-bold">
                        {card.duration === 50 ? "Finish 4 sessions" : "7-day streak or Pro"}
                      </Text>
                    </View>
                  )}
                </View>
              </TouchableOpacity>
            ))}
          </View>

          <View className="flex-row gap-3">
            <TouchableOpacity
              onPress={() => router.push("/friends")}
              className="flex-1 bg-surface rounded-2xl p-4 gap-1"
            >
              <Text className="text-muted text-xs font-bold uppercase tracking-wide">
                Focus Circles
              </Text>
              <Text className="text-xl font-bold text-foreground">
                #{data.challengeBoard[0]?.userPosition ?? 0} this week
              </Text>
              <Text className="text-muted text-xs">Compete with friends and leagues</Text>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => router.push("/premium")}
              className="flex-1 bg-surface rounded-2xl p-4 gap-1"
            >
              <Text className="text-muted text-xs font-bold uppercase tracking-wide">
                Saved Distractions
              </Text>
              <Text className="text-xl font-bold text-foreground">
                {data.distractionTimeSavedMinutes}m
              </Text>
              <Text className="text-muted text-xs">Upgrade for unlimited shield automation</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

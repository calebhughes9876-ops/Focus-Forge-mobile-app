import { ScrollView, Text, View, TouchableOpacity, TextInput, Alert, ActivityIndicator } from "react-native";
import { useState, useEffect } from "react";
import { useFocusEffect, useRouter } from "expo-router";
import AsyncStorage from "@react-native-async-storage/async-storage";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useAuthContext } from "@/lib/auth-context";

interface AppData {
  streak: number;
  xp: number;
  rank: string;
  totalFocusHours: number;
  completedSessions: number;
  sessionHistory: Array<{ duration: number; xpEarned: number; completedAt: string }>;
}

interface ProfileData {
  username: string;
  bio: string;
  avatar: string;
}

const AVATARS = ["🔥", "⚡", "💪", "🎯", "🦁", "🐺", "🦅", "🏆"];

export default function ProfileScreen() {
  const colors = useColors();
  const router = useRouter();
  const { user, isPremium } = useAuthContext();

  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showAvatarPicker, setShowAvatarPicker] = useState(false);

  const [profile, setProfile] = useState<ProfileData>({
    username: user?.name ?? "Warrior",
    bio: "Strict focus. Hard accountability.",
    avatar: "🔥",
  });

  const [editProfile, setEditProfile] = useState<ProfileData>(profile);

  const [stats, setStats] = useState<AppData>({
    streak: 0,
    xp: 0,
    rank: "Beginner",
    totalFocusHours: 0,
    completedSessions: 0,
    sessionHistory: [],
  });

  useFocusEffect(() => {
    loadAll();
  });

  const loadAll = async () => {
    if (!user) return;
    try {
      const [savedStats, savedProfile] = await Promise.all([
        AsyncStorage.getItem(`focusforge_data_${user.id}`),
        AsyncStorage.getItem(`focusforge_profile_${user.id}`),
      ]);

      if (savedStats) setStats(JSON.parse(savedStats));

      if (savedProfile) {
        const p = JSON.parse(savedProfile);
        setProfile(p);
        setEditProfile(p);
      }
    } catch (e) {
      console.log("Error loading profile:", e);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!user) return;
    if (!editProfile.username.trim()) {
      Alert.alert("Username required", "Please enter a username.");
      return;
    }
    try {
      setSaving(true);
      await AsyncStorage.setItem(
        `focusforge_profile_${user.id}`,
        JSON.stringify(editProfile)
      );
      setProfile(editProfile);
      setIsEditing(false);
    } catch {
      Alert.alert("Error", "Could not save profile. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  const handleCancel = () => {
    setEditProfile(profile);
    setIsEditing(false);
    setShowAvatarPicker(false);
  };

  if (loading) {
    return (
      <ScreenContainer className="items-center justify-center">
        <ActivityIndicator size="large" color={colors.primary} />
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer>
      <ScrollView showsVerticalScrollIndicator={false} className="flex-1">
        <View className="p-4 gap-6 pb-8">

          {/* Header */}
          <View className="flex-row items-center justify-between">
            <TouchableOpacity onPress={() => router.back()}>
              <Text className="text-primary font-semibold">← Back</Text>
            </TouchableOpacity>
            <Text className="text-2xl font-bold text-foreground">Profile</Text>
            {isEditing ? (
              <View className="flex-row gap-2">
                <TouchableOpacity onPress={handleCancel}>
                  <Text className="text-muted font-semibold">Cancel</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={handleSave} disabled={saving}>
                  <Text className="text-primary font-semibold">
                    {saving ? "Saving..." : "Save"}
                  </Text>
                </TouchableOpacity>
              </View>
            ) : (
              <TouchableOpacity onPress={() => setIsEditing(true)}>
                <Text className="text-primary font-semibold">Edit</Text>
              </TouchableOpacity>
            )}
          </View>

          {/* Avatar */}
          <View className="items-center gap-3">
            <TouchableOpacity
              onPress={() => isEditing && setShowAvatarPicker(!showAvatarPicker)}
              activeOpacity={isEditing ? 0.7 : 1}
              className="w-24 h-24 bg-primary/20 border-2 border-primary rounded-full items-center justify-center"
            >
              <Text className="text-5xl">{isEditing ? editProfile.avatar : profile.avatar}</Text>
            </TouchableOpacity>
            {isEditing && (
              <Text className="text-xs text-muted">Tap avatar to change</Text>
            )}

            {/* Avatar picker */}
            {showAvatarPicker && isEditing && (
              <View className="flex-row flex-wrap gap-3 justify-center bg-surface rounded-lg p-4">
                {AVATARS.map((a) => (
                  <TouchableOpacity
                    key={a}
                    onPress={() => {
                      setEditProfile((p) => ({ ...p, avatar: a }));
                      setShowAvatarPicker(false);
                    }}
                    className={`w-12 h-12 rounded-full items-center justify-center ${
                      editProfile.avatar === a ? "bg-primary/30 border-2 border-primary" : "bg-background"
                    }`}
                  >
                    <Text className="text-2xl">{a}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            )}
          </View>

          {/* Username */}
          <View className="gap-2">
            <Text className="text-xs text-muted font-bold uppercase tracking-wide">Username</Text>
            {isEditing ? (
              <TextInput
                value={editProfile.username}
                onChangeText={(v) => setEditProfile((p) => ({ ...p, username: v }))}
                className="bg-surface border border-border rounded-lg p-3 text-foreground"
                placeholderTextColor={colors.muted}
                maxLength={30}
              />
            ) : (
              <Text className="text-xl font-bold text-foreground">{profile.username}</Text>
            )}
          </View>

          {/* Bio */}
          <View className="gap-2">
            <Text className="text-xs text-muted font-bold uppercase tracking-wide">Bio</Text>
            {isEditing ? (
              <TextInput
                value={editProfile.bio}
                onChangeText={(v) => setEditProfile((p) => ({ ...p, bio: v }))}
                className="bg-surface border border-border rounded-lg p-3 text-foreground"
                placeholderTextColor={colors.muted}
                multiline
                numberOfLines={3}
                maxLength={120}
              />
            ) : (
              <Text className="text-foreground leading-relaxed">{profile.bio}</Text>
            )}
          </View>

          {/* Badges */}
          <View className="gap-2">
            <Text className="text-xs text-muted font-bold uppercase tracking-wide">Badges</Text>
            <View className="flex-row gap-2 flex-wrap">
              {user?.isAdmin && (
                <View className="bg-primary/20 border border-primary rounded-lg px-3 py-1">
                  <Text className="text-primary text-xs font-bold">Admin</Text>
                </View>
              )}
              {isPremium && (
                <View className="bg-warning/20 border border-warning rounded-lg px-3 py-1">
                  <Text className="text-warning text-xs font-bold">👑 Premium</Text>
                </View>
              )}
              {stats.completedSessions >= 1 && (
                <View className="bg-success/20 border border-success rounded-lg px-3 py-1">
                  <Text className="text-success text-xs font-bold">🏆 First Session</Text>
                </View>
              )}
              {stats.streak >= 7 && (
                <View className="bg-error/20 border border-error rounded-lg px-3 py-1">
                  <Text className="text-error text-xs font-bold">🔥 Week Warrior</Text>
                </View>
              )}
              {stats.completedSessions === 0 && !user?.isAdmin && !isPremium && (
                <Text className="text-muted text-sm">Complete sessions to earn badges.</Text>
              )}
            </View>
          </View>

          {/* Stats */}
          <View className="gap-3">
            <Text className="text-xs text-muted font-bold uppercase tracking-wide">Stats</Text>
            <View className="flex-row gap-3">
              <View className="flex-1 bg-surface rounded-lg p-4 items-center gap-1">
                <Text className="text-2xl font-bold text-primary">{stats.streak}</Text>
                <Text className="text-xs text-muted">Streak</Text>
              </View>
              <View className="flex-1 bg-surface rounded-lg p-4 items-center gap-1">
                <Text className="text-2xl font-bold text-primary">
                  {stats.totalFocusHours.toFixed(1)}h
                </Text>
                <Text className="text-xs text-muted">Hours</Text>
              </View>
              <View className="flex-1 bg-surface rounded-lg p-4 items-center gap-1">
                <Text className="text-2xl font-bold text-primary">{stats.completedSessions}</Text>
                <Text className="text-xs text-muted">Sessions</Text>
              </View>
            </View>
            <View className="bg-surface rounded-lg p-4 flex-row justify-between items-center">
              <Text className="text-muted text-sm">Rank</Text>
              <Text className="text-foreground font-bold">{stats.rank}</Text>
            </View>
            <View className="bg-surface rounded-lg p-4 flex-row justify-between items-center">
              <Text className="text-muted text-sm">Total XP</Text>
              <Text className="text-primary font-bold">{stats.xp} XP</Text>
            </View>
          </View>

          {/* Friends shortcut */}
          <TouchableOpacity
            onPress={() => router.push("/friends")}
            activeOpacity={0.7}
            className="bg-surface rounded-lg p-4 flex-row items-center justify-between"
          >
            <Text className="text-foreground font-semibold">Friends</Text>
            <Text className="text-primary">→</Text>
          </TouchableOpacity>

        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

import { Text, View, ScrollView } from "react-native";
import { useCallback, useState } from "react";
import { useFocusEffect } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";
import { useAuthContext } from "@/lib/auth-context";
import {
  FocusForgeData,
  buildWeeklyFocusData,
  calculateLongestStreak,
  calculateMissionCompletionRate,
  loadFocusData,
} from "@/lib/focus-data";

const EMPTY_WEEK = [0, 0, 0, 0, 0, 0, 0];

export default function ProgressScreen() {
  const { user, isPremium } = useAuthContext();
  const [data, setData] = useState<FocusForgeData | null>(null);
  const [weeklyData, setWeeklyData] = useState<number[]>(EMPTY_WEEK);

  useFocusEffect(
    useCallback(() => {
      async function loadStats() {
        if (!user) return;

        try {
          const stored = await loadFocusData(String(user.id));
          setData(stored);
          setWeeklyData(buildWeeklyFocusData(stored.sessionHistory));
        } catch (error) {
          console.log("Error loading stats:", error);
        }
      }

      loadStats();
    }, [user])
  );

  const weekDays = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  const maxHours = Math.max(...weeklyData, 1);
  const longestStreak = calculateLongestStreak(data?.sessionHistory ?? []);
  const missionCompletion = calculateMissionCompletionRate(data?.missions ?? []);
  const weeklyGoalHours = Math.round(((data?.dailyGoalMinutes ?? 75) * 7) / 60);
  const weeklyHours = weeklyData.reduce((sum, value) => sum + value, 0);
  const weeklyGoalProgress = Math.min(
    100,
    Math.round((weeklyHours / Math.max(weeklyGoalHours, 1)) * 100)
  );

  const highlights = [
    {
      title: "Focus Score",
      value: `${data?.focusScoreAverage ?? 0}`,
      subtitle: isPremium ? "Premium analytics unlocked" : "Upgrade for deeper trend analysis",
    },
    {
      title: "Saved Distractions",
      value: `${data?.distractionTimeSavedMinutes ?? 0}m`,
      subtitle: "Estimated minutes rescued by shield sessions",
    },
    {
      title: "Mission Hit Rate",
      value: `${missionCompletion}%`,
      subtitle: "Daily mission execution rate",
    },
    {
      title: "Recovery Bank",
      value: `${data?.recoveryMinutesEarned ?? 0}m`,
      subtitle: "Break time earned from completed sessions",
    },
  ];

  return (
    <ScreenContainer>
      <ScrollView showsVerticalScrollIndicator={false} className="flex-1">
        <View className="p-4 gap-6 pb-8">
          <View className="gap-1">
            <Text className="text-4xl font-bold text-foreground">Progress</Text>
            <Text className="text-muted text-sm">
              The apps that keep users pay off clear momentum. This page now shows it.
            </Text>
          </View>

          <View className="bg-primary/10 border border-primary rounded-2xl p-5 gap-3">
            <View className="flex-row items-center justify-between">
              <View>
                <Text className="text-primary text-xs font-bold uppercase tracking-wide">
                  Weekly Goal
                </Text>
                <Text className="text-2xl font-bold text-foreground">
                  {weeklyHours.toFixed(1)} / {weeklyGoalHours}h
                </Text>
              </View>
              <Text className="text-foreground font-bold text-lg">{weeklyGoalProgress}%</Text>
            </View>
            <View className="h-3 bg-background rounded-full overflow-hidden">
              <View
                className="h-full bg-primary rounded-full"
                style={{ width: `${Math.max(weeklyGoalProgress, 6)}%` }}
              />
            </View>
            <Text className="text-muted text-xs">
              Annual and lifetime plans can justify themselves when weekly progress feels tangible.
            </Text>
          </View>

          <View className="bg-surface rounded-2xl p-4">
            <Text className="text-sm font-bold text-foreground mb-4">Weekly Focus Hours</Text>
            <View className="flex-row items-end justify-between h-36 gap-2">
              {weeklyData.map((hours, index) => {
                const barHeight = maxHours > 0 ? (hours / maxHours) * 100 : 0;
                return (
                  <View key={weekDays[index]} className="flex-1 items-center gap-2">
                    <View
                      className="w-full bg-primary rounded-t-2xl"
                      style={{ height: `${Math.max(barHeight, hours > 0 ? 8 : 0)}%` }}
                    />
                    <Text className="text-xs text-muted">{weekDays[index]}</Text>
                    <Text className="text-xs font-bold text-foreground">
                      {hours > 0 ? `${hours}h` : "-"}
                    </Text>
                  </View>
                );
              })}
            </View>
          </View>

          <View className="gap-3">
            {highlights.map((item) => (
              <View
                key={item.title}
                className="bg-surface rounded-2xl p-4 flex-row items-center justify-between gap-3"
              >
                <View className="flex-1">
                  <Text className="text-muted text-xs uppercase tracking-wide">{item.title}</Text>
                  <Text className="text-3xl font-bold text-foreground mt-1">{item.value}</Text>
                  <Text className="text-muted text-xs mt-1">{item.subtitle}</Text>
                </View>
              </View>
            ))}
          </View>

          <View className="bg-surface rounded-2xl p-4 gap-3">
            <Text className="text-sm font-bold text-foreground">Milestones</Text>
            <View className="flex-row items-center justify-between">
              <Text className="text-muted text-sm">Current streak</Text>
              <Text className="text-primary font-bold text-lg">{data?.streak ?? 0} days</Text>
            </View>
            <View className="flex-row items-center justify-between">
              <Text className="text-muted text-sm">Longest streak</Text>
              <Text className="text-foreground font-bold text-lg">{longestStreak} days</Text>
            </View>
            <View className="flex-row items-center justify-between">
              <Text className="text-muted text-sm">Rank</Text>
              <Text className="text-foreground font-bold text-lg">{data?.rank ?? "Beginner"}</Text>
            </View>
            <View className="flex-row items-center justify-between">
              <Text className="text-muted text-sm">Completed sessions</Text>
              <Text className="text-success font-bold text-lg">{data?.completedSessions ?? 0}</Text>
            </View>
          </View>

          <View className="bg-surface rounded-2xl p-4 gap-3">
            <Text className="text-sm font-bold text-foreground">Challenge Momentum</Text>
            {(data?.challengeBoard ?? []).map((challenge) => {
              const challengeProgress = Math.min(
                100,
                Math.round(((challenge.currentHours ?? 0) / (challenge.targetHours ?? 1)) * 100)
              );
              return (
                <View key={challenge.id} className="gap-2">
                  <View className="flex-row items-center justify-between gap-3">
                    <View className="flex-1">
                      <Text className="text-foreground font-semibold">{challenge.title}</Text>
                      <Text className="text-muted text-xs">
                        #{challenge.userPosition} • {challenge.members} members • {challenge.prize}
                      </Text>
                    </View>
                    {challenge.premium && (
                      <View className="bg-primary/15 rounded-full px-3 py-1">
                        <Text className="text-primary text-xs font-bold">Pro</Text>
                      </View>
                    )}
                  </View>
                  <View className="h-2.5 bg-background rounded-full overflow-hidden">
                    <View
                      className="h-full bg-success rounded-full"
                      style={{ width: `${Math.max(challengeProgress, 8)}%` }}
                    />
                  </View>
                </View>
              );
            })}
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

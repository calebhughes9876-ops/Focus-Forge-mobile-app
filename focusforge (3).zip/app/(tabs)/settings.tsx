import { Text, View, ScrollView, Switch, TouchableOpacity, Alert } from "react-native";
import { useCallback, useState } from "react";
import { useFocusEffect, useRouter } from "expo-router";
import * as Haptics from "expo-haptics";
import AsyncStorage from "@react-native-async-storage/async-storage";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useAuthContext } from "@/lib/auth-context";
import { FocusForgeData, loadFocusData, saveFocusData } from "@/lib/focus-data";

export default function SettingsScreen() {
  const colors = useColors();
  const router = useRouter();
  const { user, isPremium, logout } = useAuthContext();
  const [data, setData] = useState<FocusForgeData | null>(null);

  useFocusEffect(
    useCallback(() => {
      async function loadSettings() {
        if (!user) return;
        const stored = await loadFocusData(String(user.id));
        setData(stored);
      }

      loadSettings().catch((error) => console.log("Error loading settings:", error));
    }, [user])
  );

  const settings = data?.settings;
  const notificationRows: Array<{
    key: string;
    title: string;
    subtitle: string;
  }> = [
    {
      key: "dailyReminders",
      title: "Daily Reminders",
      subtitle: "Protect your first session early",
    },
    {
      key: "missionDeadlines",
      title: "Mission Deadlines",
      subtitle: "Get warned before you miss the day",
    },
    {
      key: "streakWarnings",
      title: "Streak Warnings",
      subtitle: "Fear of loss works when the app reminds you",
    },
    {
      key: "breakReminders",
      title: "Break Reminders",
      subtitle: "Forest-style recovery pacing after a session",
    },
    {
      key: "weeklyReview",
      title: "Weekly Review",
      subtitle: "Sunday recap with score, wins, and misses",
    },
  ];

  const handleToggle = async (key: string) => {
    if (!user || !data) return;
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    
    const currentSettings = data.settings || {
      theme: "dark" as const,
      notifications: true,
      dailyReminders: true,
      missionDeadlines: true,
      streakWarnings: true,
      breakReminders: true,
      weeklyReview: true,
      dailyReminder: "09:00",
    };

    const updated: FocusForgeData = {
      ...data,
      settings: {
        ...currentSettings,
        [key]: !currentSettings[key as keyof typeof currentSettings],
      },
    };
    setData(updated);
    await saveFocusData(String(user.id), updated);
  };

  const handleExportData = async () => {
    if (!data) return;
    Alert.alert(
      "Export Preview",
      `Focus hours: ${data.totalFocusHours}\nSessions: ${data.completedSessions}\nMissions: ${data.missions.length}\nSaved distractions: ${data.distractionTimeSavedMinutes} minutes`,
      [{ text: "OK" }]
    );
  };

  const handleDeleteAccount = () => {
    Alert.alert(
      "Delete Account",
      "Are you sure? All your data will be permanently removed and cannot be recovered.",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          style: "destructive",
          onPress: async () => {
            if (user) {
              await AsyncStorage.removeItem(`focusforge_data_${user.id}`);
              await AsyncStorage.removeItem(`focusforge_friends_${user.id}`);
              await AsyncStorage.removeItem(`focusforge_requests_${user.id}`);
              await AsyncStorage.removeItem(`onboarding_completed_${user.id}`);
              setData(null);
            }
            await logout();
          },
        },
      ]
    );
  };

  const handleLogout = () => {
    Alert.alert("Sign Out", "Are you sure you want to sign out?", [
      { text: "Cancel", style: "cancel" },
      { text: "Sign Out", onPress: logout },
    ]);
  };

  return (
    <ScreenContainer>
      <ScrollView showsVerticalScrollIndicator={false} className="flex-1">
        <View className="p-4 gap-6 pb-8">
          <View className="gap-1">
            <Text className="text-4xl font-bold text-foreground">Settings</Text>
            <Text className="text-muted text-sm">
              Control reminders, shield automation, premium access, and your data.
            </Text>
          </View>

          {user && (
            <View className="bg-surface rounded-2xl p-4 gap-2">
              <Text className="text-xs text-muted font-bold uppercase tracking-wide">
                Signed in as
              </Text>
              <Text className="text-foreground font-semibold">{user.email}</Text>
              <View className="flex-row gap-2">
                <View className="bg-primary/20 rounded px-2 py-1 self-start">
                  <Text className="text-primary text-xs font-bold">
                    {data?.rank ?? "Beginner"}
                  </Text>
                </View>
                <View className="bg-success/20 rounded px-2 py-1 self-start">
                  <Text className="text-success text-xs font-bold">
                    {isPremium ? "Pro Active" : "Free Plan"}
                  </Text>
                </View>
              </View>
            </View>
          )}

          <View className="gap-3">
            <Text className="text-lg font-bold text-foreground">Focus System</Text>
            <View className="bg-surface rounded-2xl overflow-hidden">
              <View className="flex-row items-center justify-between p-4 border-b border-border">
                <View>
                  <Text className="text-foreground font-semibold">Manage Missions</Text>
                  <Text className="text-muted text-xs mt-1">Daily planner and mission rewards</Text>
                </View>
                <Text className="text-muted text-lg">→</Text>
              </View>

              <View className="flex-row items-center justify-between p-4">
                <View>
                  <Text className="text-foreground font-semibold">Focus Shield</Text>
                  <Text className="text-muted text-xs mt-1">
                    Blocklists, allowlists, schedules, and strictness presets
                  </Text>
                </View>
                <Text className="text-muted text-lg">→</Text>
              </View>
            </View>
          </View>

          <View className="gap-3">
            <Text className="text-lg font-bold text-foreground">Notifications</Text>
            <View className="bg-surface rounded-2xl overflow-hidden">
              {notificationRows.map((item, index, array) => (
                <View
                  key={item.key}
                  className={`flex-row items-center justify-between p-4 ${
                    index < array.length - 1 ? "border-b border-border" : ""
                  }`}
                >
                  <View className="flex-1 pr-4">
                    <Text className="text-foreground font-semibold">{item.title}</Text>
                    <Text className="text-muted text-xs mt-1">{item.subtitle}</Text>
                  </View>
                  <Switch
                    value={(settings as any)?.[item.key] ?? false}
                    onValueChange={() => handleToggle(item.key)}
                    trackColor={{ false: "#767577", true: colors.primary }}
                    thumbColor={(settings as any)?.[item.key] ? colors.primary : "#f4f3f4"}
                  />
                </View>
              ))}
            </View>
          </View>

          <View className="gap-3">
            <Text className="text-lg font-bold text-foreground">Data & Privacy</Text>
            <View className="bg-surface rounded-2xl overflow-hidden">
              <TouchableOpacity
                onPress={handleExportData}
                activeOpacity={0.7}
                className="flex-row items-center justify-between p-4 border-b border-border"
              >
                <View>
                  <Text className="text-foreground font-semibold">Export Data</Text>
                  <Text className="text-muted text-xs mt-1">Download your focus history</Text>
                </View>
                <Text className="text-muted text-lg">→</Text>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={handleDeleteAccount}
                activeOpacity={0.7}
                className="flex-row items-center justify-between p-4"
              >
                <View>
                  <Text className="text-error font-semibold">Delete Account</Text>
                  <Text className="text-muted text-xs mt-1">Permanently remove all data</Text>
                </View>
                <Text className="text-error text-lg">→</Text>
              </TouchableOpacity>
            </View>
          </View>

          <TouchableOpacity
            onPress={handleLogout}
            activeOpacity={0.7}
            className="bg-surface rounded-2xl p-4 items-center"
          >
            <Text className="text-foreground font-semibold">Sign Out</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

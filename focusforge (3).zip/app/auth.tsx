import { Text, View, ScrollView, TextInput, Alert, ActivityIndicator, Platform, Pressable } from "react-native";
import { useState } from "react";
import { useRouter } from "expo-router";
import * as Haptics from "expo-haptics";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useAuthContext } from "@/lib/auth-context";

type AuthMode = "login" | "signup";

export default function AuthScreen() {
  const colors = useColors();
  const router = useRouter();
  const { login, signup } = useAuthContext();
  
  const [mode, setMode] = useState<AuthMode>("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const handleAuth = async () => {
    console.log("[Auth] handleAuth called", { mode, email, loading });
    try {
      if (Platform.OS !== "web") {
        await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      }

      // Validation
      if (!email || !password) {
        Alert.alert("Error", "Please fill in all fields");
        return;
      }

      if (mode === "signup") {
        if (password !== confirmPassword) {
          Alert.alert("Error", "Passwords don't match");
          return;
        }
        if (password.length < 8) {
          Alert.alert("Error", "Password must be at least 8 characters");
          return;
        }
      }

      setLoading(true);
      console.log("[Auth] Calling", mode, "with email:", email);

      // Call login or signup from auth context
      const result = mode === "login" 
        ? await login(email, password)
        : await signup(email, password);

      console.log("[Auth] Result:", result);

      if (result.success) {
        Alert.alert("Success", mode === "signup" ? "Account created! Welcome to FocusForge!" : "Logged in successfully!");
        // Navigation is handled by auth context
      } else {
        Alert.alert("Error", result.error || "Authentication failed. Please try again.");
      }
    } catch (error) {
      Alert.alert("Error", "An unexpected error occurred. Please try again.");
      console.error("[Auth] Error:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScreenContainer containerClassName="bg-background">
      <ScrollView showsVerticalScrollIndicator={false} className="flex-1">
        <View className="flex-1 p-6 justify-center gap-6 py-12">
          {/* Header */}
          <View className="gap-3 mb-6">
            <Text className="text-5xl font-bold text-foreground tracking-tight">
              {mode === "login" ? "Sign In" : "Create Account"}
            </Text>
            <Text className="text-base text-muted leading-relaxed">
              {mode === "login" 
                ? "Welcome back to FocusForge" 
                : "Join the focus revolution"}
            </Text>
          </View>

          {/* Form */}
          <View className="gap-4">
            {/* Email */}
            <View className="gap-2.5">
              <Text className="text-xs font-semibold text-muted uppercase tracking-wide">Email</Text>
              <View 
                style={{
                  borderWidth: 1,
                  borderColor: colors.border,
                  borderRadius: 14,
                  paddingHorizontal: 16,
                  paddingVertical: 14,
                  backgroundColor: colors.surface,
                }}
              >
                <TextInput
                  placeholder="you@example.com"
                  placeholderTextColor={colors.muted}
                  value={email}
                  onChangeText={setEmail}
                  keyboardType="email-address"
                  autoCapitalize="none"
                  editable={!loading}
                  style={{
                    color: colors.foreground,
                    fontSize: 16,
                    fontWeight: "500",
                  }}
                />
              </View>
            </View>

            {/* Password */}
            <View className="gap-2.5">
              <Text className="text-xs font-semibold text-muted uppercase tracking-wide">Password</Text>
              <View 
                style={{
                  borderWidth: 1,
                  borderColor: colors.border,
                  borderRadius: 14,
                  paddingHorizontal: 16,
                  paddingVertical: 14,
                  backgroundColor: colors.surface,
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent: "space-between",
                }}
              >
                <TextInput
                  placeholder="••••••••••••"
                  placeholderTextColor={colors.muted}
                  value={password}
                  onChangeText={setPassword}
                  secureTextEntry={!showPassword}
                  editable={!loading}
                  style={{
                    color: colors.foreground,
                    fontSize: 16,
                    fontWeight: "500",
                    flex: 1,
                  }}
                />
                <Pressable onPress={() => setShowPassword(!showPassword)}>
                  <Text style={{ color: colors.muted, fontSize: 18, marginLeft: 8 }}>
                    {showPassword ? "👁️" : "👁️‍🗨️"}
                  </Text>
                </Pressable>
              </View>
            </View>

            {/* Confirm Password (Signup Only) */}
            {mode === "signup" && (
              <View className="gap-2.5">
                <Text className="text-xs font-semibold text-muted uppercase tracking-wide">Confirm Password</Text>
                <View 
                  style={{
                    borderWidth: 1,
                    borderColor: colors.border,
                    borderRadius: 14,
                    paddingHorizontal: 16,
                    paddingVertical: 14,
                    backgroundColor: colors.surface,
                  }}
                >
                  <TextInput
                    placeholder="••••••••••••"
                    placeholderTextColor={colors.muted}
                    value={confirmPassword}
                    onChangeText={setConfirmPassword}
                    secureTextEntry
                    editable={!loading}
                    style={{
                      color: colors.foreground,
                      fontSize: 16,
                      fontWeight: "500",
                    }}
                  />
                </View>
              </View>
            )}

            {/* Remember Me & Forgot Password (Login Only) */}
            {mode === "login" && (
              <View className="flex-row justify-between items-center">
                <View className="flex-row items-center gap-2">
                  <Pressable
                    onPress={() => setRememberMe(!rememberMe)}
                    style={{
                      width: 20,
                      height: 20,
                      borderRadius: 4,
                      borderWidth: 2,
                      borderColor: rememberMe ? colors.primary : colors.border,
                      backgroundColor: rememberMe ? colors.primary : "transparent",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    {rememberMe && (
                      <Text style={{ color: colors.background, fontSize: 12, fontWeight: "bold" }}>✓</Text>
                    )}
                  </Pressable>
                  <Text className="text-sm text-foreground">Remember me</Text>
                </View>
                <Pressable onPress={() => router.push("/forgot-password")}>
                  <Text style={{ color: colors.primary, fontSize: 14, fontWeight: "600" }}>
                    Forgot password?
                  </Text>
                </Pressable>
              </View>
            )}
          </View>

          {/* Submit Button with Gradient */}
          <Pressable
            onPress={handleAuth}
            disabled={loading}
            style={({ pressed }) => ({
              paddingVertical: 18,
              alignItems: "center",
              borderRadius: 14,
              background: "linear-gradient(90deg, #1DD1A1 0%, #00D9FF 100%)",
              backgroundColor: "#1DD1A1",
              opacity: pressed && !loading ? 0.85 : 1,
              transform: pressed && !loading ? [{scale: 0.98}] : [{scale: 1}],
            })}
          >
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={{ color: "#fff", fontWeight: "600", fontSize: 16, letterSpacing: 0.5 }}>
                {mode === "login" ? "Sign In" : "Create Account"}
              </Text>
            )}
          </Pressable>

          {/* Social Login (Login Only) */}
          {mode === "login" && (
            <>
              <View className="flex-row items-center gap-3">
                <View style={{ flex: 1, height: 1, backgroundColor: colors.border }} />
                <Text className="text-sm text-muted">Or Sign in with</Text>
                <View style={{ flex: 1, height: 1, backgroundColor: colors.border }} />
              </View>

              <View className="flex-row gap-3">
                <Pressable
                  style={{
                    flex: 1,
                    borderWidth: 1,
                    borderColor: colors.border,
                    borderRadius: 12,
                    paddingVertical: 12,
                    alignItems: "center",
                    backgroundColor: colors.surface,
                  }}
                >
                  <Text className="text-lg">f</Text>
                  <Text className="text-sm text-foreground font-semibold">Facebook</Text>
                </Pressable>

                <Pressable
                  style={{
                    flex: 1,
                    borderWidth: 1,
                    borderColor: colors.border,
                    borderRadius: 12,
                    paddingVertical: 12,
                    alignItems: "center",
                    backgroundColor: colors.surface,
                  }}
                >
                  <Text className="text-lg">G</Text>
                  <Text className="text-sm text-foreground font-semibold">Google</Text>
                </Pressable>
              </View>
            </>
          )}

          {/* Toggle Mode */}
          <View className="flex-row justify-center gap-2">
            <Text className="text-sm text-muted">
              {mode === "login" 
                ? "Don't have an account? " 
                : "Already have an account? "}
            </Text>
            <Pressable onPress={() => setMode(mode === "login" ? "signup" : "login")}>
              <Text style={{ color: colors.primary, fontSize: 14, fontWeight: "600" }}>
                {mode === "login" ? "Sign Up" : "Sign In"}
              </Text>
            </Pressable>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

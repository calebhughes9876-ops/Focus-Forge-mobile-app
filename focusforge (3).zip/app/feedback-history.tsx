import { Text, View, ScrollView, TouchableOpacity, FlatList } from "react-native";
import { useState, useEffect } from "react";
import { useRouter } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { getUserFeedback, Feedback, getFeedbackStats } from "@/lib/feedback-service";

export default function FeedbackHistoryScreen() {
  const colors = useColors();
  const router = useRouter();
  const [feedbackList, setFeedbackList] = useState<Feedback[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadFeedback();
  }, []);

  const loadFeedback = async () => {
    setLoading(true);
    const feedback = await getUserFeedback();
    const feedbackStats = await getFeedbackStats();
    setFeedbackList(feedback.reverse()); // Most recent first
    setStats(feedbackStats);
    setLoading(false);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "submitted":
        return "#94A3B8";
      case "reviewing":
        return "#3B82F6";
      case "in-progress":
        return "#F59E0B";
      case "resolved":
        return "#10B981";
      case "wontfix":
        return "#EF4444";
      default:
        return colors.muted;
    }
  };

  const getTypeEmoji = (type: string) => {
    switch (type) {
      case "bug":
        return "🐛";
      case "feature":
        return "✨";
      case "improvement":
        return "📈";
      case "other":
        return "💬";
      default:
        return "📝";
    }
  };

  const renderFeedbackItem = ({ item }: { item: Feedback }) => (
    <TouchableOpacity
      activeOpacity={0.7}
      className="bg-surface rounded-lg p-4 mb-3 border"
      style={{ borderColor: colors.border }}
    >
      <View className="gap-2">
        {/* Header */}
        <View className="flex-row items-start justify-between">
          <View className="flex-1 gap-1">
            <Text className="text-foreground font-bold text-base">
              {getTypeEmoji(item.type)} {item.title}
            </Text>
            <Text className="text-xs text-muted">{new Date(item.createdAt).toLocaleDateString()}</Text>
          </View>
          <View
            style={{ backgroundColor: getStatusColor(item.status) }}
            className="rounded-full px-2 py-1"
          >
            <Text className="text-white text-xs font-bold capitalize">{item.status}</Text>
          </View>
        </View>

        {/* Description */}
        <Text className="text-muted text-sm line-clamp-2">{item.description}</Text>

        {/* Footer */}
        <View className="flex-row items-center justify-between pt-2 border-t" style={{ borderColor: colors.border }}>
          <View className="flex-row gap-3">
            <Text className="text-xs text-muted">👍 {item.votes}</Text>
            <Text className="text-xs text-muted capitalize">Priority: {item.priority}</Text>
          </View>
        </View>

        {/* Response */}
        {item.response && (
          <View className="bg-background rounded p-2 mt-2">
            <Text className="text-xs font-bold text-primary mb-1">Team Response:</Text>
            <Text className="text-xs text-muted">{item.response}</Text>
          </View>
        )}
      </View>
    </TouchableOpacity>
  );

  return (
    <ScreenContainer>
      <ScrollView showsVerticalScrollIndicator={false} className="flex-1 p-4">
        <View className="gap-6">
          {/* Header */}
          <View className="gap-2">
            <Text className="text-3xl font-bold text-foreground">Feedback History</Text>
            <Text className="text-muted text-sm">View your submitted feedback</Text>
          </View>

          {/* Stats */}
          {stats && (
            <View className="bg-surface rounded-lg p-4 gap-3">
              <Text className="text-sm font-bold text-foreground">Your Feedback</Text>
              <View className="flex-row gap-2">
                <View className="flex-1 bg-background rounded p-2">
                  <Text className="text-2xl font-bold text-primary text-center">{stats.total}</Text>
                  <Text className="text-xs text-muted text-center">Total</Text>
                </View>
                <View className="flex-1 bg-background rounded p-2">
                  <Text className="text-2xl font-bold text-primary text-center">{stats.byStatus.resolved}</Text>
                  <Text className="text-xs text-muted text-center">Resolved</Text>
                </View>
                <View className="flex-1 bg-background rounded p-2">
                  <Text className="text-2xl font-bold text-primary text-center">{stats.byStatus.reviewing}</Text>
                  <Text className="text-xs text-muted text-center">Reviewing</Text>
                </View>
              </View>
            </View>
          )}

          {/* Feedback List */}
          {loading ? (
            <Text className="text-muted text-center py-8">Loading...</Text>
          ) : feedbackList.length === 0 ? (
            <View className="bg-surface rounded-lg p-8 items-center gap-3">
              <Text className="text-4xl">📝</Text>
              <Text className="text-foreground font-bold">No feedback yet</Text>
              <Text className="text-muted text-sm text-center">
                Submit your first feedback to help us improve FocusForge
              </Text>
              <TouchableOpacity
                onPress={() => router.push("/(tabs)")}
                activeOpacity={0.8}
                style={{ backgroundColor: colors.primary }}
                className="rounded-full px-6 py-2 mt-2"
              >
                <Text className="text-background font-bold text-sm">Send Feedback</Text>
              </TouchableOpacity>
            </View>
          ) : (
            <View>
              <FlatList
                data={feedbackList}
                renderItem={renderFeedbackItem}
                keyExtractor={item => item.id}
                scrollEnabled={false}
              />
            </View>
          )}

          {/* Action Button */}
          {feedbackList.length > 0 && (
            <TouchableOpacity
              onPress={() => router.push("/(tabs)")}
              activeOpacity={0.8}
              style={{ backgroundColor: colors.primary }}
              className="rounded-full py-4 items-center"
            >
              <Text className="text-background font-bold text-lg">Send More Feedback</Text>
            </TouchableOpacity>
          )}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

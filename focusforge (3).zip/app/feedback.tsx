import { Text, View, ScrollView, TouchableOpacity, TextInput, Alert } from "react-native";
import { useState } from "react";
import { useRouter } from "expo-router";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { submitFeedback, FeedbackType } from "@/lib/feedback-service";

export default function FeedbackScreen() {
  const colors = useColors();
  const router = useRouter();
  const [feedbackType, setFeedbackType] = useState<FeedbackType>("bug");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [email, setEmail] = useState("");
  const [priority, setPriority] = useState<"low" | "medium" | "high" | "critical">("medium");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const feedbackTypes: { value: FeedbackType; label: string; emoji: string }[] = [
    { value: "bug", label: "Bug Report", emoji: "🐛" },
    { value: "feature", label: "Feature Request", emoji: "✨" },
    { value: "improvement", label: "Improvement", emoji: "📈" },
    { value: "other", label: "Other", emoji: "💬" },
  ];

  const priorities = [
    { value: "low", label: "Low", color: "#4ADE80" },
    { value: "medium", label: "Medium", color: "#FBBF24" },
    { value: "high", label: "High", color: "#FB923C" },
    { value: "critical", label: "Critical", color: "#EF4444" },
  ];

  const handleSubmit = async () => {
    if (!title.trim()) {
      Alert.alert("Error", "Please enter a title");
      return;
    }

    if (!description.trim()) {
      Alert.alert("Error", "Please enter a description");
      return;
    }

    setIsSubmitting(true);

    const result = await submitFeedback(feedbackType, title, description, email, priority);

    setIsSubmitting(false);

    if (result.success) {
      Alert.alert("Success", "Thank you! Your feedback has been submitted.", [
        {
          text: "OK",
          onPress: () => router.back(),
        },
      ]);
      setTitle("");
      setDescription("");
      setEmail("");
      setPriority("medium");
    } else {
      Alert.alert("Error", result.error || "Failed to submit feedback");
    }
  };

  return (
    <ScreenContainer>
      <ScrollView showsVerticalScrollIndicator={false} className="flex-1 p-4">
        <View className="gap-6">
          {/* Header */}
          <View className="gap-2">
            <Text className="text-3xl font-bold text-foreground">Send Feedback</Text>
            <Text className="text-muted text-sm">Help us improve FocusForge</Text>
          </View>

          {/* Feedback Type */}
          <View className="gap-3">
            <Text className="text-sm font-bold text-foreground">Feedback Type</Text>
            <View className="gap-2">
              {feedbackTypes.map(type => (
                <TouchableOpacity
                  key={type.value}
                  onPress={() => setFeedbackType(type.value)}
                  activeOpacity={0.7}
                  className={`p-3 rounded-lg border ${
                    feedbackType === type.value
                      ? "border-primary bg-primary/10"
                      : "border-border bg-surface"
                  }`}
                >
                  <Text className="text-foreground font-medium">
                    {type.emoji} {type.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          {/* Priority */}
          <View className="gap-3">
            <Text className="text-sm font-bold text-foreground">Priority</Text>
            <View className="flex-row gap-2">
              {priorities.map(p => (
                <TouchableOpacity
                  key={p.value}
                  onPress={() => setPriority(p.value as any)}
                  activeOpacity={0.7}
                  style={{
                    backgroundColor: priority === p.value ? p.color : `${p.color}20`,
                    borderColor: p.color,
                  }}
                  className="flex-1 p-3 rounded-lg border"
                >
                  <Text
                    style={{
                      color: priority === p.value ? "white" : p.color,
                    }}
                    className="font-bold text-center text-sm"
                  >
                    {p.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          {/* Title */}
          <View className="gap-2">
            <Text className="text-sm font-bold text-foreground">Title</Text>
            <TextInput
              value={title}
              onChangeText={setTitle}
              placeholder="Brief summary of your feedback"
              placeholderTextColor={colors.muted}
              maxLength={100}
              style={{
                backgroundColor: colors.surface,
                color: colors.foreground,
                borderColor: colors.border,
              }}
              className="border rounded-lg p-3 text-foreground"
            />
            <Text className="text-xs text-muted">{title.length}/100</Text>
          </View>

          {/* Description */}
          <View className="gap-2">
            <Text className="text-sm font-bold text-foreground">Description</Text>
            <TextInput
              value={description}
              onChangeText={setDescription}
              placeholder="Detailed description of your feedback or steps to reproduce"
              placeholderTextColor={colors.muted}
              multiline
              numberOfLines={6}
              maxLength={1000}
              textAlignVertical="top"
              style={{
                backgroundColor: colors.surface,
                color: colors.foreground,
                borderColor: colors.border,
              }}
              className="border rounded-lg p-3 text-foreground"
            />
            <Text className="text-xs text-muted">{description.length}/1000</Text>
          </View>

          {/* Email (Optional) */}
          <View className="gap-2">
            <Text className="text-sm font-bold text-foreground">Email (Optional)</Text>
            <TextInput
              value={email}
              onChangeText={setEmail}
              placeholder="your@email.com"
              placeholderTextColor={colors.muted}
              keyboardType="email-address"
              style={{
                backgroundColor: colors.surface,
                color: colors.foreground,
                borderColor: colors.border,
              }}
              className="border rounded-lg p-3 text-foreground"
            />
            <Text className="text-xs text-muted">We'll use this to follow up with you</Text>
          </View>

          {/* Submit Button */}
          <TouchableOpacity
            onPress={handleSubmit}
            disabled={isSubmitting}
            activeOpacity={0.8}
            style={{
              backgroundColor: isSubmitting ? colors.muted : colors.primary,
            }}
            className="rounded-full py-4 items-center mt-4"
          >
            <Text className="text-background font-bold text-lg">
              {isSubmitting ? "Submitting..." : "Submit Feedback"}
            </Text>
          </TouchableOpacity>

          {/* Info */}
          <View className="bg-surface rounded-lg p-4 gap-2">
            <Text className="text-xs font-bold text-foreground">💡 Tips:</Text>
            <Text className="text-xs text-muted">
              • Be specific and detailed{"\n"}• Include steps to reproduce bugs{"\n"}• Suggest solutions when possible
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

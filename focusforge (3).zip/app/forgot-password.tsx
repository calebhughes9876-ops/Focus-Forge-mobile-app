import { Text, View, ScrollView, TextInput, Alert, ActivityIndicator, Platform, Pressable } from "react-native";
import { useState } from "react";
import { useRouter } from "expo-router";
import * as Haptics from "expo-haptics";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

type ResetStep = "email" | "otp";

export default function ForgotPasswordScreen() {
  const colors = useColors();
  const router = useRouter();
  
  const [step, setStep] = useState<ResetStep>("email");
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState(["", "", "", ""]);
  const [loading, setLoading] = useState(false);

  const handleRequestReset = async () => {
    try {
      if (Platform.OS !== "web") {
        await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      }

      if (!email) {
        Alert.alert("Error", "Please enter your email address");
        return;
      }

      setLoading(true);
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));

      Alert.alert("Success", "Password reset code sent to your email");
      setStep("otp");
    } catch (error) {
      Alert.alert("Error", "Failed to send reset email");
      console.error("Error:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOTP = async () => {
    try {
      if (Platform.OS !== "web") {
        await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      }

      const otpCode = otp.join("");
      if (otpCode.length !== 4) {
        Alert.alert("Error", "Please enter all 4 digits");
        return;
      }

      setLoading(true);
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));

      Alert.alert("Success", "Password reset link sent to your email");
      router.replace("/auth");
    } catch (error) {
      Alert.alert("Error", "Invalid OTP");
      console.error("Error:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScreenContainer containerClassName="bg-background">
      <ScrollView showsVerticalScrollIndicator={false} className="flex-1">
        <View className="flex-1 p-6 justify-center gap-6 py-12">
          {step === "email" ? (
            <>
              {/* Header */}
              <View className="gap-2 mb-4">
                <Text className="text-4xl font-bold text-foreground">Forgot Password</Text>
                <Text className="text-base text-muted">
                  Enter the email associated with your account and we'll send an email instructions to reset your password.
                </Text>
              </View>

              {/* Email Input */}
              <View className="gap-4">
                <View className="gap-2">
                  <Text className="text-sm font-semibold text-foreground">Email</Text>
                  <View 
                    style={{
                      borderWidth: 1,
                      borderColor: colors.border,
                      borderRadius: 12,
                      paddingHorizontal: 16,
                      paddingVertical: 12,
                      backgroundColor: colors.surface,
                    }}
                  >
                    <TextInput
                      placeholder="serena88@gmail.com"
                      placeholderTextColor={colors.muted}
                      value={email}
                      onChangeText={setEmail}
                      keyboardType="email-address"
                      autoCapitalize="none"
                      editable={!loading}
                      style={{
                        color: colors.foreground,
                        fontSize: 16,
                      }}
                    />
                  </View>
                </View>

                {/* Submit Button */}
                <Pressable
                  onPress={handleRequestReset}
                  disabled={loading}
                  style={({ pressed }) => ({
                    paddingVertical: 16,
                    alignItems: "center",
                    borderRadius: 12,
                    backgroundColor: "#1DD1A1",
                    opacity: pressed && !loading ? 0.8 : 1,
                  })}
                >
                  {loading ? (
                    <ActivityIndicator color="#fff" />
                  ) : (
                    <Text style={{ color: "#fff", fontWeight: "bold", fontSize: 16 }}>
                      Continue
                    </Text>
                  )}
                </Pressable>
              </View>
            </>
          ) : (
            <>
              {/* Verification Header */}
              <View className="gap-2 mb-4">
                <Text className="text-4xl font-bold text-foreground">Verification</Text>
                <Text className="text-base text-muted">
                  Enter the 4 digits code that you received on your email.
                </Text>
              </View>

              {/* OTP Input */}
              <View className="gap-6">
                <View className="flex-row justify-between gap-3">
                  {otp.map((digit, index) => (
                    <TextInput
                      key={index}
                      value={digit}
                      onChangeText={(text) => {
                        if (text.length <= 1 && /^\d*$/.test(text)) {
                          const newOtp = [...otp];
                          newOtp[index] = text;
                          setOtp(newOtp);
                        }
                      }}
                      keyboardType="number-pad"
                      maxLength={1}
                      style={{
                        flex: 1,
                        borderWidth: 1,
                        borderColor: colors.border,
                        borderRadius: 12,
                        paddingVertical: 16,
                        textAlign: "center",
                        fontSize: 20,
                        fontWeight: "bold",
                        color: colors.foreground,
                        backgroundColor: colors.surface,
                      }}
                      placeholder="0"
                      placeholderTextColor={colors.muted}
                    />
                  ))}
                </View>

                {/* Resend OTP */}
                <View className="flex-row justify-center gap-2">
                  <Text className="text-sm text-muted">Didn't receive the OTP? </Text>
                  <Pressable onPress={() => Alert.alert("OTP Resent", "A new code has been sent to your email")}>
                    <Text style={{ color: colors.primary, fontSize: 14, fontWeight: "600" }}>
                      Resend OTP
                    </Text>
                  </Pressable>
                </View>

                {/* Verify Button */}
                <Pressable
                  onPress={handleVerifyOTP}
                  disabled={loading}
                  style={({ pressed }) => ({
                    paddingVertical: 16,
                    alignItems: "center",
                    borderRadius: 12,
                    backgroundColor: "#1DD1A1",
                    opacity: pressed && !loading ? 0.8 : 1,
                  })}
                >
                  {loading ? (
                    <ActivityIndicator color="#fff" />
                  ) : (
                    <Text style={{ color: "#fff", fontWeight: "bold", fontSize: 16 }}>
                      Continue
                    </Text>
                  )}
                </Pressable>
              </View>
            </>
          )}

          {/* Back to Login */}
          <View className="flex-row justify-center gap-2 mt-4">
            <Pressable onPress={() => router.replace("/auth")}>
              <Text style={{ color: colors.primary, fontSize: 14, fontWeight: "600" }}>
                ← Back to Login
              </Text>
            </Pressable>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

import { ScrollView, Text, View, TouchableOpacity, TextInput, Alert } from "react-native";
import { useState, useEffect } from "react";
import { ScreenContainer } from "@/components/screen-container";
import { useRouter } from "expo-router";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useAuthContext } from "@/lib/auth-context";
import { useColors } from "@/hooks/use-colors";

interface Friend {
  id: string;
  name: string;
  avatar: string;
  streak: number;
  addedAt: string;
}

interface FriendRequest {
  id: string;
  name: string;
  avatar: string;
  sentAt: string;
}

const MOCK_SEARCH_RESULTS = [
  { id: "s1", name: "FocusWarrior", avatar: "⚡", streak: 21 },
  { id: "s2", name: "DisciplinedAlex", avatar: "🦁", streak: 14 },
  { id: "s3", name: "GrindsetJordan", avatar: "💪", streak: 8 },
];

export default function FriendsScreen() {
  const router = useRouter();
  const colors = useColors();
  const { user } = useAuthContext();

  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState<"friends" | "requests" | "search">("friends");
  const [friends, setFriends] = useState<Friend[]>([]);
  const [requests, setRequests] = useState<FriendRequest[]>([]);
  const [searchResults, setSearchResults] = useState<typeof MOCK_SEARCH_RESULTS>([]);
  const [searching, setSearching] = useState(false);

  useEffect(() => {
    loadFriendsData();
  }, []);

  const loadFriendsData = async () => {
    if (!user) return;
    try {
      const [savedFriends, savedRequests] = await Promise.all([
        AsyncStorage.getItem(`focusforge_friends_${user.id}`),
        AsyncStorage.getItem(`focusforge_requests_${user.id}`),
      ]);
      if (savedFriends) setFriends(JSON.parse(savedFriends));
      if (savedRequests) setRequests(JSON.parse(savedRequests));
    } catch (e) {
      console.log("Error loading friends:", e);
    }
  };

  const saveFriends = async (updated: Friend[]) => {
    if (!user) return;
    await AsyncStorage.setItem(`focusforge_friends_${user.id}`, JSON.stringify(updated));
  };

  const saveRequests = async (updated: FriendRequest[]) => {
    if (!user) return;
    await AsyncStorage.setItem(`focusforge_requests_${user.id}`, JSON.stringify(updated));
  };

  const handleSearch = () => {
    if (!searchQuery.trim()) return;
    setSearching(true);
    // Filter mock results - in production this would hit an API
    setTimeout(() => {
      const results = MOCK_SEARCH_RESULTS.filter(
        (r) =>
          r.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
          !friends.find((f) => f.id === r.id)
      );
      setSearchResults(results);
      setSearching(false);
    }, 400);
  };

  const handleAddFriend = async (result: typeof MOCK_SEARCH_RESULTS[0]) => {
    const newRequest: FriendRequest = {
      id: result.id,
      name: result.name,
      avatar: result.avatar,
      sentAt: new Date().toISOString(),
    };
    const updated = [...requests, newRequest];
    setRequests(updated);
    await saveRequests(updated);
    setSearchResults((prev) => prev.filter((r) => r.id !== result.id));
    Alert.alert("Request Sent", `Friend request sent to ${result.name}.`);
  };

  const handleAccept = async (request: FriendRequest) => {
    const newFriend: Friend = {
      id: request.id,
      name: request.name,
      avatar: request.avatar,
      streak: Math.floor(Math.random() * 30) + 1,
      addedAt: new Date().toISOString(),
    };
    const updatedFriends = [...friends, newFriend];
    const updatedRequests = requests.filter((r) => r.id !== request.id);
    setFriends(updatedFriends);
    setRequests(updatedRequests);
    await Promise.all([saveFriends(updatedFriends), saveRequests(updatedRequests)]);
  };

  const handleDecline = async (request: FriendRequest) => {
    const updated = requests.filter((r) => r.id !== request.id);
    setRequests(updated);
    await saveRequests(updated);
  };

  const handleRemoveFriend = (friend: Friend) => {
    Alert.alert(
      "Remove Friend",
      `Remove ${friend.name} from your friends list?`,
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Remove",
          style: "destructive",
          onPress: async () => {
            const updated = friends.filter((f) => f.id !== friend.id);
            setFriends(updated);
            await saveFriends(updated);
          },
        },
      ]
    );
  };

  const tabs: Array<{ key: "friends" | "requests" | "search"; label: string; count?: number }> = [
    { key: "friends", label: "Friends", count: friends.length },
    { key: "requests", label: "Requests", count: requests.length || undefined },
    { key: "search", label: "Search" },
  ];

  return (
    <ScreenContainer>
      <ScrollView showsVerticalScrollIndicator={false} className="flex-1">
        <View className="p-4 gap-4 pb-8">

          {/* Header */}
          <View className="flex-row items-center justify-between">
            <TouchableOpacity onPress={() => router.back()}>
              <Text className="text-primary font-semibold">← Back</Text>
            </TouchableOpacity>
            <Text className="text-2xl font-bold text-foreground">Friends</Text>
            <View style={{ width: 60 }} />
          </View>

          {/* Tabs */}
          <View className="flex-row gap-2">
            {tabs.map((tab) => (
              <TouchableOpacity
                key={tab.key}
                onPress={() => setActiveTab(tab.key)}
                className={`flex-1 py-2 px-2 rounded-lg items-center ${
                  activeTab === tab.key ? "bg-primary" : "bg-surface border border-border"
                }`}
              >
                <Text
                  className={`font-semibold text-xs ${
                    activeTab === tab.key ? "text-background" : "text-foreground"
                  }`}
                >
                  {tab.label}
                  {tab.count !== undefined ? ` (${tab.count})` : ""}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* Friends List */}
          {activeTab === "friends" && (
            <View className="gap-3">
              {friends.length === 0 ? (
                <View className="bg-surface rounded-lg p-6 items-center gap-2">
                  <Text className="text-3xl">👥</Text>
                  <Text className="text-foreground font-bold">No friends yet</Text>
                  <Text className="text-muted text-sm text-center">
                    Search for other FocusForge users to add as friends.
                  </Text>
                  <TouchableOpacity
                    onPress={() => setActiveTab("search")}
                    className="mt-2"
                  >
                    <Text className="text-primary font-semibold">Find Friends</Text>
                  </TouchableOpacity>
                </View>
              ) : (
                friends.map((friend) => (
                  <TouchableOpacity
                    key={friend.id}
                    onLongPress={() => handleRemoveFriend(friend)}
                    activeOpacity={0.8}
                    className="bg-surface rounded-lg p-4 flex-row items-center justify-between border border-border"
                  >
                    <View className="flex-row items-center gap-3 flex-1">
                      <View className="w-12 h-12 bg-primary/20 rounded-full items-center justify-center">
                        <Text className="text-2xl">{friend.avatar}</Text>
                      </View>
                      <View className="flex-1">
                        <Text className="font-bold text-foreground">{friend.name}</Text>
                        <Text className="text-xs text-muted">🔥 {friend.streak} day streak</Text>
                      </View>
                    </View>
                    <View className="w-2 h-2 rounded-full bg-success" />
                  </TouchableOpacity>
                ))
              )}
              {friends.length > 0 && (
                <Text className="text-muted text-xs text-center">
                  Long press a friend to remove them.
                </Text>
              )}
            </View>
          )}

          {/* Friend Requests */}
          {activeTab === "requests" && (
            <View className="gap-3">
              {requests.length === 0 ? (
                <View className="bg-surface rounded-lg p-6 items-center gap-2">
                  <Text className="text-3xl">📬</Text>
                  <Text className="text-foreground font-bold">No pending requests</Text>
                  <Text className="text-muted text-sm text-center">
                    Friend requests you send will appear here.
                  </Text>
                </View>
              ) : (
                requests.map((request) => (
                  <View
                    key={request.id}
                    className="bg-surface rounded-lg p-4 border border-border gap-3"
                  >
                    <View className="flex-row items-center gap-3">
                      <View className="w-12 h-12 bg-primary/20 rounded-full items-center justify-center">
                        <Text className="text-2xl">{request.avatar}</Text>
                      </View>
                      <View className="flex-1">
                        <Text className="font-bold text-foreground">{request.name}</Text>
                        <Text className="text-xs text-muted">Request pending</Text>
                      </View>
                    </View>
                    <View className="flex-row gap-2">
                      <TouchableOpacity
                        onPress={() => handleAccept(request)}
                        className="flex-1 bg-primary rounded-lg py-2 items-center"
                      >
                        <Text className="text-background font-semibold text-sm">Accept</Text>
                      </TouchableOpacity>
                      <TouchableOpacity
                        onPress={() => handleDecline(request)}
                        className="flex-1 bg-surface border border-border rounded-lg py-2 items-center"
                      >
                        <Text className="text-foreground font-semibold text-sm">Decline</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                ))
              )}
            </View>
          )}

          {/* Search */}
          {activeTab === "search" && (
            <View className="gap-3">
              <View className="flex-row gap-2">
                <TextInput
                  placeholder="Search by username..."
                  value={searchQuery}
                  onChangeText={setSearchQuery}
                  onSubmitEditing={handleSearch}
                  returnKeyType="search"
                  className="flex-1 bg-surface border border-border rounded-lg p-3 text-foreground"
                  placeholderTextColor={colors.muted}
                />
                <TouchableOpacity
                  onPress={handleSearch}
                  disabled={searching}
                  style={{ backgroundColor: colors.primary }}
                  className="rounded-lg px-4 items-center justify-center"
                >
                  <Text className="text-background font-bold">
                    {searching ? "..." : "Go"}
                  </Text>
                </TouchableOpacity>
              </View>

              {searchResults.length > 0 && (
                <View className="gap-2">
                  {searchResults.map((result) => (
                    <View
                      key={result.id}
                      className="bg-surface rounded-lg p-4 flex-row items-center justify-between border border-border"
                    >
                      <View className="flex-row items-center gap-3 flex-1">
                        <View className="w-12 h-12 bg-primary/20 rounded-full items-center justify-center">
                          <Text className="text-2xl">{result.avatar}</Text>
                        </View>
                        <View className="flex-1">
                          <Text className="font-bold text-foreground">{result.name}</Text>
                          <Text className="text-xs text-muted">🔥 {result.streak} day streak</Text>
                        </View>
                      </View>
                      <TouchableOpacity
                        onPress={() => handleAddFriend(result)}
                        style={{ backgroundColor: colors.primary }}
                        className="px-3 py-2 rounded-lg"
                      >
                        <Text className="text-background font-semibold text-sm">Add</Text>
                      </TouchableOpacity>
                    </View>
                  ))}
                </View>
              )}

              {searchQuery.length > 0 && searchResults.length === 0 && !searching && (
                <View className="bg-surface rounded-lg p-6 items-center gap-2">
                  <Text className="text-muted text-sm">No results for "{searchQuery}"</Text>
                </View>
              )}

              {searchQuery.length === 0 && (
                <View className="bg-surface rounded-lg p-6 items-center gap-2">
                  <Text className="text-3xl">🔍</Text>
                  <Text className="text-muted text-sm text-center">
                    Search for other FocusForge users by their username.
                  </Text>
                </View>
              )}
            </View>
          )}

        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

import { Text, View, TouchableOpacity, ScrollView, Alert } from "react-native";
import { useState } from "react";
import { useRouter } from "expo-router";
import * as Linking from "expo-linking";
import * as SecureStore from "expo-secure-store";
import * as Haptics from "expo-haptics";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

const OAUTH_CLIENT_ID = "focusforge-app";
const OAUTH_REDIRECT_URI = "focusforge://oauth-callback";
const OAUTH_AUTHORIZE_URL = "https://auth.manus.im/authorize";

export default function LoginScreen() {
  const colors = useColors();
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    try {
      await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      setLoading(true);

      // Generate random state for security
      const state = Math.random().toString(36).substring(7);
      await SecureStore.setItemAsync("oauth_state", state);

      // Build OAuth URL
      const params = new URLSearchParams({
        client_id: OAUTH_CLIENT_ID,
        redirect_uri: OAUTH_REDIRECT_URI,
        response_type: "code",
        state: state,
        scope: "openid profile email",
      });

      const authUrl = `${OAUTH_AUTHORIZE_URL}?${params.toString()}`;

      // Open browser for OAuth
      await Linking.openURL(authUrl);
    } catch (error) {
      console.error("Login error:", error);
      Alert.alert("Error", "Failed to open login. Please try again.");
      setLoading(false);
    }
  };

  const handleGuestContinue = async () => {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    // Store guest mode flag
    await SecureStore.setItemAsync("guest_mode", "true");
    router.replace("/(tabs)");
  };

  return (
    <ScreenContainer>
      <ScrollView showsVerticalScrollIndicator={false} className="flex-1">
        <View className="flex-1 p-4 justify-center gap-8">
          {/* Logo */}
          <View className="items-center gap-4">
            <Text className="text-8xl">🔥</Text>
            <Text className="text-4xl font-bold text-foreground">FocusForge</Text>
            <Text className="text-muted text-center">Strict focus. Hard accountability.</Text>
          </View>

          {/* Features */}
          <View className="bg-surface rounded-lg p-4 gap-3">
            <Text className="text-sm font-bold text-foreground mb-2">Why Create an Account?</Text>
            <View className="gap-2">
              <Text className="text-muted text-sm">✓ Sync progress across devices</Text>
              <Text className="text-muted text-sm">✓ Unlock premium features</Text>
              <Text className="text-muted text-sm">✓ Access AI Coach</Text>
              <Text className="text-muted text-sm">✓ Backup your streaks</Text>
            </View>
          </View>

          {/* Login Button */}
          <TouchableOpacity
            onPress={handleLogin}
            disabled={loading}
            activeOpacity={0.8}
            style={{ backgroundColor: colors.primary }}
            className="rounded-full py-4 items-center"
          >
            <Text className="text-background font-bold text-lg">
              {loading ? "Opening..." : "Sign In / Create Account"}
            </Text>
          </TouchableOpacity>

          {/* Divider */}
          <View className="flex-row items-center gap-3">
            <View className="flex-1 h-px bg-border" />
            <Text className="text-muted text-xs">or</Text>
            <View className="flex-1 h-px bg-border" />
          </View>

          {/* Guest Mode */}
          <TouchableOpacity
            onPress={handleGuestContinue}
            activeOpacity={0.7}
            className="rounded-full py-4 items-center border-2 border-primary"
          >
            <Text className="text-primary font-bold text-lg">Continue as Guest</Text>
            <Text className="text-muted text-xs mt-1">(Local data only)</Text>
          </TouchableOpacity>

          {/* Info */}
          <View className="bg-primary/10 border border-primary rounded-lg p-3">
            <Text className="text-primary text-xs text-center font-semibold">
              Guest mode stores data locally. Sign in to sync across devices.
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

import { Text, View, ScrollView, TouchableOpacity, Dimensions } from "react-native";
import { useState } from "react";
import { useRouter } from "expo-router";
import * as Haptics from "expo-haptics";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useAuthContext } from "@/lib/auth-context";

interface OnboardingStep {
  id: number;
  title: string;
  description: string;
  icon: string;
  tips: string[];
}

const ONBOARDING_STEPS: OnboardingStep[] = [
  {
    id: 1,
    title: "Welcome to FocusForge",
    description: "Your strict focus companion for hard accountability.",
    icon: "🔥",
    tips: [
      "FocusForge is designed for disciplined individuals who refuse to compromise",
      "Every session counts toward your streak",
      "Consistency is key to unlocking advanced features",
    ],
  },
  {
    id: 2,
    title: "How Focus Sessions Work",
    description: "Choose your duration and commit to staying focused.",
    icon: "⏱️",
    tips: [
      "Start with 15 or 25 minute sessions",
      "Unlock 45 min after 3 completed sessions",
      "Unlock 90 min after maintaining a 7-day streak",
      "Each session earns you XP and builds your streak",
    ],
  },
  {
    id: 3,
    title: "Build Your Streak",
    description: "Complete at least one session every day to maintain your streak.",
    icon: "🔥",
    tips: [
      "Your streak resets if you miss a day",
      "Longer streaks unlock premium features",
      "Exiting a session will break your streak",
      "Stay disciplined and stay focused",
    ],
  },
  {
    id: 4,
    title: "Earn XP & Rank Up",
    description: "Earn experience points with every completed session.",
    icon: "⭐",
    tips: [
      "15 min session = 25 XP",
      "25 min session = 50 XP",
      "45 min session = 100 XP",
      "90 min session = 150 XP",
      "Rank up: Beginner → Focused → Elite",
    ],
  },
  {
    id: 5,
    title: "Premium Features",
    description: "Unlock exclusive features with a premium subscription.",
    icon: "👑",
    tips: [
      "AI Accountability Coach for personalized guidance",
      "Advanced analytics and insights",
      "Priority support",
      "$5.99/month or $49.99/year",
    ],
  },
  {
    id: 6,
    title: "You're Ready!",
    description: "Start your first focus session and build your discipline.",
    icon: "💪",
    tips: [
      "Your stats start fresh - no preloaded data",
      "Every session is tracked and counted",
      "Your progress is saved automatically",
      "Let's get focused!",
    ],
  },
];

export default function OnboardingScreen() {
  const colors = useColors();
  const router = useRouter();
  const { completeOnboarding } = useAuthContext();
  const [currentStep, setCurrentStep] = useState(0);

  const step = ONBOARDING_STEPS[currentStep];
  const isLastStep = currentStep === ONBOARDING_STEPS.length - 1;
  const progress = ((currentStep + 1) / ONBOARDING_STEPS.length) * 100;

  const handleNext = async () => {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    if (isLastStep) {
      await completeOnboarding();
      router.replace("/(tabs)");
    } else {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleSkip = async () => {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    await completeOnboarding();
    router.replace("/(tabs)");
  };

  const handlePrevious = async () => {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  return (
    <ScreenContainer>
      <ScrollView showsVerticalScrollIndicator={false} className="flex-1">
        <View className="p-4 gap-6 py-8">
          {/* Progress Bar */}
          <View className="gap-2">
            <View className="flex-row justify-between items-center">
              <Text className="text-sm font-bold text-muted">
                Step {currentStep + 1} of {ONBOARDING_STEPS.length}
              </Text>
              <TouchableOpacity onPress={handleSkip}>
                <Text className="text-sm font-semibold text-primary">Skip</Text>
              </TouchableOpacity>
            </View>
            <View className="h-2 bg-surface rounded-full overflow-hidden">
              <View
                className="h-full bg-primary rounded-full"
                style={{ width: `${progress}%` }}
              />
            </View>
          </View>

          {/* Icon */}
          <View className="items-center">
            <Text className="text-8xl">{step.icon}</Text>
          </View>

          {/* Title */}
          <View className="gap-2">
            <Text className="text-4xl font-bold text-foreground text-center">
              {step.title}
            </Text>
            <Text className="text-lg text-muted text-center">{step.description}</Text>
          </View>

          {/* Tips */}
          <View className="gap-3 bg-surface rounded-lg p-4">
            {step.tips.map((tip, index) => (
              <View key={index} className="flex-row gap-3">
                <Text className="text-primary font-bold text-lg">•</Text>
                <Text className="flex-1 text-foreground text-sm leading-relaxed">
                  {tip}
                </Text>
              </View>
            ))}
          </View>

          {/* Navigation Buttons */}
          <View className="gap-3 mt-4">
            {/* Next Button */}
            <TouchableOpacity
              onPress={handleNext}
              activeOpacity={0.8}
              style={{ backgroundColor: colors.primary }}
              className="rounded-full py-4 items-center"
            >
              <Text className="text-background font-bold text-lg">
                {isLastStep ? "Start FocusForge" : "Next"}
              </Text>
            </TouchableOpacity>

            {/* Previous Button */}
            {currentStep > 0 && (
              <TouchableOpacity
                onPress={handlePrevious}
                activeOpacity={0.8}
                className="rounded-full py-4 items-center border-2 border-primary"
              >
                <Text className="text-primary font-bold text-lg">Previous</Text>
              </TouchableOpacity>
            )}
          </View>

          {/* Dots Indicator */}
          <View className="flex-row justify-center gap-2 mt-4">
            {ONBOARDING_STEPS.map((_, index) => (
              <View
                key={index}
                className={`rounded-full ${
                  index === currentStep ? "bg-primary" : "bg-surface"
                }`}
                style={{
                  width: index === currentStep ? 12 : 8,
                  height: 8,
                }}
              />
            ))}
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

import { Text, View, ScrollView, TouchableOpacity, Alert, ActivityIndicator } from "react-native";
import { useState } from "react";
import { useRouter } from "expo-router";
import * as Haptics from "expo-haptics";
import * as SecureStore from "expo-secure-store";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useAuthContext } from "@/lib/auth-context";

type PaymentMethod = "stripe" | "paypal" | "applepay" | null;

export default function PremiumScreen() {
  const colors = useColors();
  const router = useRouter();
  const { refreshPremiumStatus } = useAuthContext();
  const [selectedPlan, setSelectedPlan] = useState<"monthly" | "yearly">("monthly");
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>(null);
  const [processing, setProcessing] = useState(false);

  const plans = {
    monthly: {
      price: "$5.99",
      period: "/month",
      savings: null,
      features: [
        "AI Accountability Coach",
        "Daily check-ins",
        "Personalised feedback",
        "Advanced analytics",
        "Custom punishments",
      ],
    },
    yearly: {
      price: "$49.99",
      period: "/year",
      savings: "Save 30%",
      features: [
        "Everything in Monthly",
        "Priority support",
        "Early access to features",
        "Lifetime stats",
      ],
    },
  };

  const handlePayment = async (method: PaymentMethod) => {
    if (!method) return;

    try {
      await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      setPaymentMethod(method);
      setProcessing(true);

      // Simulate payment processing delay
      await new Promise((resolve) => setTimeout(resolve, 2000));

      const expiresAt = new Date();
      if (selectedPlan === "monthly") {
        expiresAt.setMonth(expiresAt.getMonth() + 1);
      } else {
        expiresAt.setFullYear(expiresAt.getFullYear() + 1);
      }

      await SecureStore.setItemAsync("premium_active", "true");
      await SecureStore.setItemAsync("premium_expires_at", expiresAt.toISOString());
      await SecureStore.setItemAsync("subscription_plan", selectedPlan);

      // Refresh context so Coach screen unlocks immediately without restart
      await refreshPremiumStatus();

      Alert.alert(
        "Payment Successful!",
        `You are now a premium member. Enjoy ${selectedPlan} access to all features.`,
        [
          {
            text: "Go to Coach",
            onPress: () => router.replace("/(tabs)/coach"),
          },
        ]
      );
    } catch (error) {
      Alert.alert("Payment Failed", "Please try again or contact support.");
      console.error("Payment error:", error);
    } finally {
      setProcessing(false);
      setPaymentMethod(null);
    }
  };

  const currentPlan = plans[selectedPlan];

  return (
    <ScreenContainer>
      <ScrollView showsVerticalScrollIndicator={false} className="flex-1">
        <View className="p-4 gap-6 pb-8">
          {/* Header */}
          <View className="items-center gap-2">
            <Text className="text-6xl">👑</Text>
            <Text className="text-3xl font-bold text-foreground">Go Premium</Text>
            <Text className="text-muted text-center">Unlock AI Coach and advanced features</Text>
          </View>

          {/* Plan Toggle */}
          <View className="flex-row gap-2 bg-surface rounded-lg p-1">
            <TouchableOpacity
              onPress={() => setSelectedPlan("monthly")}
              activeOpacity={0.7}
              className={`flex-1 rounded-lg py-3 items-center ${
                selectedPlan === "monthly" ? "bg-primary" : ""
              }`}
            >
              <Text
                className={`font-bold ${
                  selectedPlan === "monthly" ? "text-background" : "text-foreground"
                }`}
              >
                Monthly
              </Text>
              <Text
                className={`text-xs ${
                  selectedPlan === "monthly" ? "text-background/80" : "text-muted"
                }`}
              >
                $5.99/mo
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => setSelectedPlan("yearly")}
              activeOpacity={0.7}
              className={`flex-1 rounded-lg py-3 items-center ${
                selectedPlan === "yearly" ? "bg-primary" : ""
              }`}
            >
              <Text
                className={`font-bold ${
                  selectedPlan === "yearly" ? "text-background" : "text-foreground"
                }`}
              >
                Yearly
              </Text>
              <Text
                className={`text-xs ${
                  selectedPlan === "yearly" ? "text-background/80" : "text-muted"
                }`}
              >
                $49.99/yr
              </Text>
            </TouchableOpacity>
          </View>

          {/* Price Display */}
          <View className="bg-primary/10 border border-primary rounded-lg p-4 items-center gap-1">
            <Text className="text-4xl font-bold text-primary">{currentPlan.price}</Text>
            <Text className="text-muted text-sm">{currentPlan.period}</Text>
            {currentPlan.savings && (
              <Text className="text-success font-bold text-sm mt-2">
                ✓ {currentPlan.savings}
              </Text>
            )}
          </View>

          {/* Features */}
          <View className="bg-surface rounded-lg p-4 gap-3">
            <Text className="text-sm font-bold text-foreground mb-2">What You Get:</Text>
            {currentPlan.features.map((feature, idx) => (
              <View key={idx} className="flex-row gap-2 items-center">
                <Text className="text-primary font-bold">✓</Text>
                <Text className="text-muted text-sm flex-1">{feature}</Text>
              </View>
            ))}
          </View>

          {/* Payment Methods */}
          <View className="gap-2">
            <Text className="text-sm font-bold text-foreground">Payment Method:</Text>

            <TouchableOpacity
              onPress={() => handlePayment("stripe")}
              disabled={processing}
              activeOpacity={0.7}
              className="bg-surface border border-border rounded-lg p-4 flex-row items-center justify-between"
            >
              <View className="flex-row items-center gap-3">
                <Text className="text-2xl">💳</Text>
                <View>
                  <Text className="text-foreground font-bold">Credit/Debit Card</Text>
                  <Text className="text-muted text-xs">Visa, Mastercard, Amex</Text>
                </View>
              </View>
              {processing && paymentMethod === "stripe" && (
                <ActivityIndicator color={colors.primary} />
              )}
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => handlePayment("paypal")}
              disabled={processing}
              activeOpacity={0.7}
              className="bg-surface border border-border rounded-lg p-4 flex-row items-center justify-between"
            >
              <View className="flex-row items-center gap-3">
                <Text className="text-2xl">🅿️</Text>
                <View>
                  <Text className="text-foreground font-bold">PayPal</Text>
                  <Text className="text-muted text-xs">Fast and secure</Text>
                </View>
              </View>
              {processing && paymentMethod === "paypal" && (
                <ActivityIndicator color={colors.primary} />
              )}
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => handlePayment("applepay")}
              disabled={processing}
              activeOpacity={0.7}
              className="bg-surface border border-border rounded-lg p-4 flex-row items-center justify-between"
            >
              <View className="flex-row items-center gap-3">
                <Text className="text-2xl">🍎</Text>
                <View>
                  <Text className="text-foreground font-bold">Apple Pay</Text>
                  <Text className="text-muted text-xs">One-tap payment</Text>
                </View>
              </View>
              {processing && paymentMethod === "applepay" && (
                <ActivityIndicator color={colors.primary} />
              )}
            </TouchableOpacity>
          </View>

          {/* Info */}
          <View className="bg-primary/10 border border-primary rounded-lg p-3">
            <Text className="text-primary text-xs text-center font-semibold">
              Cancel anytime. No commitment. Payments are secure and encrypted.
            </Text>
          </View>

          {/* Back Button */}
          <TouchableOpacity
            onPress={() => router.back()}
            activeOpacity={0.7}
            className="rounded-full py-3 items-center border border-border"
          >
            <Text className="text-foreground font-bold">Not Now</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

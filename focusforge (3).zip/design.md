# FocusForge Mobile App - Design Plan

## Overview

FocusForge is a "strict focus system that forces progress" with an emphasis on hard accountability. The app is designed for disciplined individuals who refuse to compromise on their goals. The design prioritizes a clean, aggressive, minimal aesthetic with dark mode as default, high contrast, and one primary action per screen.

## Screen List

| Screen | Purpose | Key Components |
|--------|---------|-----------------|
| **Home** | Main hub and daily engagement | Streak counter, Rank display, Start Focus Session button, Today's Missions checklist, Progress summary |
| **Focus Mode** | Immersive focus session | Full-screen timer, Unbypassable blocking, End session (hidden/hold-to-exit), No navigation visible |
| **Progress** | Track improvement over time | Weekly graph (hours focused), Streak history, Completion rate, Personal bests |
| **AI Coach** | Premium accountability | Chat interface, Daily prompt ("Why did you fail?"), Quick reply buttons, Direct/confrontational tone |
| **Settings** | App configuration | Theme toggle, Notification preferences, Premium subscription, Account settings, Data export |
| **Mission Detail** | Create/edit daily missions | Mission name, Type (time-based or task-based), Deadline/duration, Difficulty level, Save/Delete |
| **Punishment History** | View past penalties | Streak losses, Score drops, Feature locks, Reputation changes with timestamps |

## Primary Content and Functionality

### Home Screen
- **Top Section**: Streak counter (e.g., "🔥 12 Day Streak"), Rank badge (Beginner/Focused/Elite), XP progress bar
- **Center Section**: Large "Start Focus Session" button (primary action), Session duration selector (45, 60, 90, 120 mins)
- **Middle Section**: "Today's Missions" checklist with 1-3 items, each showing completion status and deadline
- **Bottom Section**: Quick stats (Hours focused today, Missions completed, Distraction time avoided)

### Focus Mode Screen
- **Full-screen timer**: Large, prominent countdown display
- **Visual feedback**: Progress ring or bar showing session progress
- **Minimal UI**: Only time remaining and a hold-to-exit button (intentionally difficult to access)
- **Psychological pressure**: No distractions, locked-in feeling, high pressure to complete

### Progress Screen
- **Weekly graph**: Line chart showing hours focused per day
- **Streak history**: Visual timeline of current and past streaks
- **Completion rate**: Percentage of missions completed this week/month
- **Personal bests**: Longest streak, most hours in a day, highest XP earned
- **Filter options**: View by week, month, or all-time

### AI Coach Screen (Premium)
- **Chat interface**: Messages from AI coach and user responses
- **Daily prompt**: "You failed yesterday. What happened?" with context
- **Quick reply buttons**: Pre-written responses to guide reflection
- **Adaptive feedback**: AI responses based on user input and performance data
- **Tone**: Direct, slightly confrontational, but motivating

### Settings Screen
- **Theme**: Dark/Light mode toggle
- **Notifications**: Daily reminders, mission deadlines, streak warnings
- **Premium**: Subscribe, manage subscription, view benefits
- **Account**: Profile, data export, delete account
- **About**: App version, feedback, support

## Key User Flows

### Flow 1: Daily Mission Completion
1. User opens app (Home screen)
2. Sees today's missions and current streak
3. Taps "Start Focus Session" button
4. Selects session duration (45-120 mins)
5. Enters Focus Mode (unbypassable)
6. Timer counts down with no distractions
7. Session completes → Mission marked complete
8. Streak increases, XP awarded
9. Returns to Home screen

### Flow 2: Failing a Mission
1. User misses mission deadline (e.g., didn't study for 2 hours)
2. App detects failure at deadline time
3. Punishment applied: Streak lost, Score drops, Reputation decreases
4. Push notification: "Streak lost. 0 day streak."
5. AI Coach sends message: "You failed yesterday. What happened?"
6. User reflects and responds
7. AI provides feedback and adaptive goals for next day

### Flow 3: Viewing Progress
1. User taps "Progress" tab
2. Sees weekly graph of focused hours
3. Scrolls to view streak history and personal bests
4. Filters data by time period (week, month, all-time)
5. Exports data for personal analysis

### Flow 4: Premium Subscription
1. User taps "Coach" tab (locked for free tier)
2. Sees "Unlock AI Coach" prompt
3. Taps "Subscribe" button
4. Chooses subscription plan ($5-10 NZD/month)
5. Completes payment
6. Coach feature unlocked
7. Daily check-ins begin

## Color Choices

**Brand Colors** (Dark Mode Default):
- **Primary**: `#FF6B35` (Aggressive Orange) - For primary actions, highlights
- **Background**: `#0F0F0F` (Deep Black) - Main screen background
- **Surface**: `#1A1A1A` (Dark Gray) - Cards, elevated surfaces
- **Foreground**: `#FFFFFF` (White) - Primary text
- **Muted**: `#808080` (Medium Gray) - Secondary text
- **Success**: `#22C55E` (Green) - Streak, completed missions
- **Error**: `#EF4444` (Red) - Failures, punishments
- **Warning**: `#F59E0B` (Amber) - Warnings, upcoming deadlines

**Light Mode** (Optional):
- **Background**: `#FFFFFF` (White)
- **Surface**: `#F5F5F5` (Light Gray)
- **Foreground**: `#0F0F0F` (Dark Gray)
- **Primary**: `#FF6B35` (Same Orange)

## Design Principles

1. **Aggressive & Minimal**: No clutter, high contrast, one primary action per screen
2. **Dark Mode Default**: Aligns with the "strict" and "focused" aesthetic
3. **Psychological Pressure**: UI design reinforces commitment (e.g., hold-to-exit in Focus Mode)
4. **Identity Reinforcement**: Streak counter and rank system make users feel disciplined
5. **Direct Feedback**: Immediate visual and haptic feedback for all actions
6. **One-Handed Usage**: All primary actions accessible with thumb on portrait orientation

## Technical Considerations

- **Local-First**: Use AsyncStorage for missions, streaks, and progress data
- **Background Timers**: Reliable timer system for focus sessions even when app is backgrounded
- **Notifications**: Push notifications for daily reminders, mission deadlines, and AI coach messages
- **App Blocking**: Android-first implementation for strict focus mode; iOS via Screen Time API integration
- **Performance**: Optimize animations and transitions for smooth 60fps experience
- **Offline-First**: Core features work without internet; sync with server when available (if implemented)

## Retention Mechanics

1. **Daily Reminder Notifications**: Push notification at 9 AM to encourage daily engagement
2. **Streak Loss Fear**: Visual prominence of streak counter creates fear of losing progress
3. **Visible Progress Improvement**: Weekly graph shows tangible improvement over time
4. **Identity Reinforcement**: Rank system and XP make users internalize "I am disciplined"
5. **Social Accountability**: Optional sharing of progress (future feature)
6. **AI Coach Pressure**: Direct, confrontational feedback from AI creates accountability

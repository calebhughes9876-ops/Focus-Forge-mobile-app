CREATE TABLE `focusSessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`duration` int NOT NULL,
	`xpEarned` int NOT NULL,
	`completed` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `focusSessions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `userStats` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`streak` int NOT NULL DEFAULT 0,
	`xp` int NOT NULL DEFAULT 0,
	`totalFocusHours` int NOT NULL DEFAULT 0,
	`completedSessions` int NOT NULL DEFAULT 0,
	`isPremium` int NOT NULL DEFAULT 0,
	`premiumExpiresAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `userStats_id` PRIMARY KEY(`id`),
	CONSTRAINT `userStats_userId_unique` UNIQUE(`userId`)
);

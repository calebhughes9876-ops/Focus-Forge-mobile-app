CREATE TABLE `feedback` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`type` enum('bug','feature','improvement','other') NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text NOT NULL,
	`email` varchar(320),
	`priority` enum('low','medium','high','critical') NOT NULL DEFAULT 'medium',
	`status` enum('submitted','reviewing','in-progress','resolved','wontfix') NOT NULL DEFAULT 'submitted',
	`response` text,
	`votes` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `feedback_id` PRIMARY KEY(`id`)
);

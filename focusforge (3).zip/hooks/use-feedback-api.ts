import { trpc } from "@/lib/trpc";
import { useState, useCallback } from "react";

export function useFeedbackAPI() {
  const [error, setError] = useState<string | null>(null);

  const submitMutation = trpc.feedback.submit.useMutation();
  const listQuery = trpc.feedback.list.useQuery();
  const statsQuery = trpc.feedback.getStats.useQuery();
  const voteMutation = trpc.feedback.vote.useMutation();
  const userFeedbackQuery = trpc.feedback.getUserFeedback.useQuery();

  const submitFeedback = useCallback(
    async (data: {
      type: "bug" | "feature" | "improvement" | "other";
      title: string;
      description: string;
      email?: string;
      priority?: "low" | "medium" | "high" | "critical";
    }) => {
      setError(null);

      try {
        const result = await submitMutation.mutateAsync({
          type: data.type,
          title: data.title,
          description: data.description,
          email: data.email,
          priority: data.priority || "medium",
        });

        return result;
      } catch (err) {
        const errorMessage = err instanceof Error ? err.message : "Failed to submit feedback";
        setError(errorMessage);
        throw err;
      }
    },
    [submitMutation]
  );

  const voteFeedback = useCallback(
    async (feedbackId: number) => {
      setError(null);

      try {
        const result = await voteMutation.mutateAsync({ id: feedbackId });
        return result;
      } catch (err) {
        const errorMessage = err instanceof Error ? err.message : "Failed to vote";
        setError(errorMessage);
        throw err;
      }
    },
    [voteMutation]
  );

  return {
    // Mutations
    submitFeedback,
    voteFeedback,
    isSubmitting: submitMutation.isPending,
    isVoting: voteMutation.isPending,

    // Queries
    feedbackList: listQuery.data || [],
    feedbackStats: statsQuery.data,
    userFeedback: userFeedbackQuery.data || [],

    // Query states
    isLoadingList: listQuery.isLoading,
    isLoadingStats: statsQuery.isLoading,
    isLoadingUserFeedback: userFeedbackQuery.isLoading,

    // Error
    error,

    // Refetch
    refetchList: listQuery.refetch,
    refetchStats: statsQuery.refetch,
    refetchUserFeedback: userFeedbackQuery.refetch,
  };
}

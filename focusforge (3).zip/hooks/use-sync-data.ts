import { useEffect, useRef } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as SecureStore from "expo-secure-store";
import { useAuthContext } from "@/lib/auth-context";

interface SyncedData {
  streak: number;
  xp: number;
  totalFocusHours: number;
  completedSessions: number;
  isPremium: boolean;
  lastSyncedAt: string;
}

export function useSyncData() {
  const { user, isAuthenticated } = useAuthContext();
  const syncTimeoutRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (!isAuthenticated) return;

    // Sync data to backend every 30 seconds
    syncTimeoutRef.current = setInterval(async () => {
      await syncToBackend();
    }, 30000);

    // Sync immediately on mount
    syncToBackend();

    return () => {
      if (syncTimeoutRef.current) {
        clearInterval(syncTimeoutRef.current);
      }
    };
  }, [isAuthenticated, user]);

  const syncToBackend = async (): Promise<void> => {
    try {
      if (!user) return;

      // Get local data
      const localData = await AsyncStorage.getItem("focusforge_data");
      if (!localData) return;

      const data = JSON.parse(localData);

      // Get last sync time
      const lastSync = await SecureStore.getItemAsync("last_sync_time");
      const lastSyncTime = lastSync ? new Date(lastSync) : new Date(0);

      // Only sync if data has changed since last sync
      const dataStr = JSON.stringify(data);
      const dataHash = await SecureStore.getItemAsync("data_hash");
      const currentHash = hashString(dataStr);

      if (dataHash === currentHash && lastSyncTime.getTime() > Date.now() - 60000) {
        return; // Data hasn't changed, skip sync
      }

      // In production, send to backend via tRPC
      // await trpc.stats.update.mutate(data);

      // Store sync metadata
      await SecureStore.setItemAsync("last_sync_time", new Date().toISOString());
      await SecureStore.setItemAsync("data_hash", currentHash);

      console.log("Data synced to backend");
    } catch (error) {
      console.error("Sync error:", error);
    }
  };

  const pullFromBackend = async () => {
    try {
      if (!user) return;

      // In production, fetch from backend via tRPC
      // const backendData = await trpc.stats.get.query();

      // For now, just return local data
      const localData = await AsyncStorage.getItem("focusforge_data");
      return localData ? JSON.parse(localData) : null;
    } catch (error) {
      console.error("Pull error:", error);
      return null;
    }
  };

  return { syncToBackend, pullFromBackend };
}

function hashString(str: string): string {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash = hash & hash; // Convert to 32bit integer
  }
  return hash.toString();
}

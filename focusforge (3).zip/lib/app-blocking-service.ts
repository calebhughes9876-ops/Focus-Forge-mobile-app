import { Platform } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

interface BlockedApp {
  packageName: string;
  name: string;
  blocked: boolean;
}

const DEFAULT_BLOCKED_APPS: BlockedApp[] = [
  { packageName: "com.facebook.katana", name: "Facebook", blocked: true },
  { packageName: "com.twitter.android", name: "Twitter", blocked: true },
  { packageName: "com.instagram.android", name: "Instagram", blocked: true },
  { packageName: "com.tiktok.android", name: "TikTok", blocked: true },
  { packageName: "com.reddit.frontpage", name: "Reddit", blocked: true },
  { packageName: "com.snapchat.android", name: "Snapchat", blocked: true },
  { packageName: "com.discord", name: "Discord", blocked: true },
  { packageName: "com.whatsapp", name: "WhatsApp", blocked: true },
  { packageName: "com.android.chrome", name: "Chrome", blocked: true },
  { packageName: "com.android.systemui", name: "System UI", blocked: false },
];

export async function initializeAppBlocking() {
  try {
    const blocked = await AsyncStorage.getItem("blocked_apps");
    if (!blocked) {
      await AsyncStorage.setItem("blocked_apps", JSON.stringify(DEFAULT_BLOCKED_APPS));
    }
    console.log("App blocking initialized");
    return true;
  } catch (error) {
    console.error("Error initializing app blocking:", error);
    return false;
  }
}

export async function getBlockedApps(): Promise<BlockedApp[]> {
  try {
    const blocked = await AsyncStorage.getItem("blocked_apps");
    return blocked ? JSON.parse(blocked) : DEFAULT_BLOCKED_APPS;
  } catch (error) {
    console.error("Error getting blocked apps:", error);
    return DEFAULT_BLOCKED_APPS;
  }
}

export async function updateBlockedApps(apps: BlockedApp[]) {
  try {
    await AsyncStorage.setItem("blocked_apps", JSON.stringify(apps));
    console.log("Blocked apps updated");
    return true;
  } catch (error) {
    console.error("Error updating blocked apps:", error);
    return false;
  }
}

export async function enableAppBlocking(focusDurationMinutes: number) {
  try {
    const isAndroid = Platform.OS === "android";
    const isIOS = Platform.OS === "ios";

    if (isAndroid) {
      // For Android, we would use:
      // - DeviceAdminReceiver to block apps
      // - Work Profile API for app blocking
      // - Accessibility Service for monitoring
      console.log(`[Android] Enabling app blocking for ${focusDurationMinutes} minutes`);
      
      // Store blocking state
      await AsyncStorage.setItem("app_blocking_active", "true");
      await AsyncStorage.setItem("app_blocking_end_time", 
        new Date(Date.now() + focusDurationMinutes * 60000).toISOString()
      );
    } else if (isIOS) {
      // For iOS, we would use:
      // - Screen Time API (ScreenTimeAPI framework)
      // - MDM (Mobile Device Management) for enterprise
      // - Supervised device restrictions
      console.log(`[iOS] Enabling app blocking for ${focusDurationMinutes} minutes`);
      
      // Store blocking state
      await AsyncStorage.setItem("app_blocking_active", "true");
      await AsyncStorage.setItem("app_blocking_end_time", 
        new Date(Date.now() + focusDurationMinutes * 60000).toISOString()
      );
    }

    return { success: true, platform: Platform.OS };
  } catch (error) {
    console.error("Error enabling app blocking:", error);
    return { success: false, error: error instanceof Error ? error.message : "Failed to enable blocking" };
  }
}

export async function disableAppBlocking() {
  try {
    await AsyncStorage.removeItem("app_blocking_active");
    await AsyncStorage.removeItem("app_blocking_end_time");
    console.log("App blocking disabled");
    return { success: true };
  } catch (error) {
    console.error("Error disabling app blocking:", error);
    return { success: false, error: error instanceof Error ? error.message : "Failed to disable blocking" };
  }
}

export async function isAppBlockingActive(): Promise<boolean> {
  try {
    const active = await AsyncStorage.getItem("app_blocking_active");
    if (active !== "true") return false;

    const endTime = await AsyncStorage.getItem("app_blocking_end_time");
    if (!endTime) return false;

    const endDate = new Date(endTime);
    const now = new Date();

    if (endDate <= now) {
      // Blocking time has expired
      await disableAppBlocking();
      return false;
    }

    return true;
  } catch (error) {
    console.error("Error checking app blocking status:", error);
    return false;
  }
}

export async function getAppBlockingTimeRemaining(): Promise<number | null> {
  try {
    const endTime = await AsyncStorage.getItem("app_blocking_end_time");
    if (!endTime) return null;

    const endDate = new Date(endTime);
    const now = new Date();
    const remainingMs = endDate.getTime() - now.getTime();

    if (remainingMs <= 0) {
      await disableAppBlocking();
      return null;
    }

    return Math.ceil(remainingMs / 1000); // Return seconds
  } catch (error) {
    console.error("Error getting app blocking time:", error);
    return null;
  }
}

export async function addCustomBlockedApp(packageName: string, name: string) {
  try {
    const apps = await getBlockedApps();
    
    // Check if already exists
    if (apps.find(app => app.packageName === packageName)) {
      return { success: false, error: "App already in blocked list" };
    }

    apps.push({ packageName, name, blocked: true });
    await updateBlockedApps(apps);
    
    return { success: true };
  } catch (error) {
    console.error("Error adding blocked app:", error);
    return { success: false, error: error instanceof Error ? error.message : "Failed to add app" };
  }
}

export async function removeBlockedApp(packageName: string) {
  try {
    const apps = await getBlockedApps();
    const filtered = apps.filter(app => app.packageName !== packageName);
    await updateBlockedApps(filtered);
    
    return { success: true };
  } catch (error) {
    console.error("Error removing blocked app:", error);
    return { success: false, error: error instanceof Error ? error.message : "Failed to remove app" };
  }
}

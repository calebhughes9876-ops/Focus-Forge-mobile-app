import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import * as SecureStore from "expo-secure-store";
import { useRouter } from "expo-router";
import AsyncStorage from "@react-native-async-storage/async-storage";

interface User {
  id: number;
  email: string;
  name: string;
  openId: string;
  isAdmin?: boolean;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  isPremium: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  signup: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  showOnboarding: boolean;
  completeOnboarding: () => Promise<void>;
  refreshPremiumStatus: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const ADMIN_EMAIL = "admin@focusforge.app";
const ADMIN_PASSWORD = "admin123";

// Grant permanent premium to admin account
const grantAdminPremium = async () => {
  const farFuture = new Date();
  farFuture.setFullYear(farFuture.getFullYear() + 99);
  await SecureStore.setItemAsync("premium_active", "true");
  await SecureStore.setItemAsync("premium_expires_at", farFuture.toISOString());
  await SecureStore.setItemAsync("subscription_plan", "admin");
};

// Initialize fresh user data keyed by userId
const initializeUserData = async (userId: number) => {
  const freshData = {
    userId,
    streak: 0,
    xp: 0,
    rank: "Beginner",
    totalFocusHours: 0,
    completedSessions: 0,
    lastSessionDate: null,
    createdAt: new Date().toISOString(),
    sessionHistory: [],
    weeklyData: [0, 0, 0, 0, 0, 0, 0],
  };
  await AsyncStorage.setItem(`focusforge_data_${userId}`, JSON.stringify(freshData));
  return freshData;
};

const checkPremiumValid = async (): Promise<boolean> => {
  try {
    const premiumActive = await SecureStore.getItemAsync("premium_active");
    const expiresAt = await SecureStore.getItemAsync("premium_expires_at");
    if (premiumActive !== "true" || !expiresAt) return false;
    return new Date(expiresAt) > new Date();
  } catch {
    return false;
  }
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [isPremium, setIsPremium] = useState(false);
  const router = useRouter();

  useEffect(() => {
    checkAuthStatus();
  }, []);

  useEffect(() => {
    if (!isLoading) {
      if (!user) {
        router.replace("/auth");
      } else {
        router.replace("/(tabs)");
      }
    }
  }, [isLoading, user, router]);

  const checkAuthStatus = async () => {
    try {
      const token = await SecureStore.getItemAsync("auth_token");
      if (token) {
        const userData = await SecureStore.getItemAsync("user_data");
        if (userData) {
          const parsedUser = JSON.parse(userData);
          setUser(parsedUser);

          if (parsedUser.isAdmin) {
            await grantAdminPremium();
          }

          const premium = await checkPremiumValid();
          setIsPremium(premium);

          const hasCompletedOnboarding = await AsyncStorage.getItem(
            `onboarding_completed_${parsedUser.id}`
          );
          setShowOnboarding(!hasCompletedOnboarding);
        }
      }
    } catch (error) {
      console.error("Auth check error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const refreshPremiumStatus = async () => {
    const premium = await checkPremiumValid();
    setIsPremium(premium);
  };

  const login = async (
    email: string,
    password: string
  ): Promise<{ success: boolean; error?: string }> => {
    try {
      setIsLoading(true);

      if (!email || !password) {
        return { success: false, error: "Email and password are required" };
      }

      const isAdmin = email === ADMIN_EMAIL && password === ADMIN_PASSWORD;
      const userId = isAdmin ? 999 : Math.floor(Math.random() * 100000) + 1000;

      const loginUser: User = {
        id: userId,
        email,
        name: email.split("@")[0],
        openId: `user_${Date.now()}`,
        isAdmin,
      };

      await SecureStore.setItemAsync("auth_token", `token_${Date.now()}`);
      await SecureStore.setItemAsync("user_data", JSON.stringify(loginUser));

      if (isAdmin) {
        await grantAdminPremium();
        setIsPremium(true);
      } else {
        const premium = await checkPremiumValid();
        setIsPremium(premium);
      }

      // Only initialise fresh data if no existing data for this user
      const existingData = await AsyncStorage.getItem(`focusforge_data_${userId}`);
      if (!existingData) {
        await initializeUserData(userId);
      }

      setUser(loginUser);
      return { success: true };
    } catch (error) {
      console.error("Login error:", error);
      return { success: false, error: "Login failed. Please try again." };
    } finally {
      setIsLoading(false);
    }
  };

  const signup = async (
    email: string,
    password: string
  ): Promise<{ success: boolean; error?: string }> => {
    try {
      setIsLoading(true);

      if (!email || !password) {
        return { success: false, error: "Email and password are required" };
      }

      if (password.length < 8) {
        return { success: false, error: "Password must be at least 8 characters" };
      }

      const userId = Math.floor(Math.random() * 100000) + 1000;

      const newUser: User = {
        id: userId,
        email,
        name: email.split("@")[0],
        openId: `user_${Date.now()}`,
        isAdmin: false,
      };

      await SecureStore.setItemAsync("auth_token", `token_${Date.now()}`);
      await SecureStore.setItemAsync("user_data", JSON.stringify(newUser));

      // New signups always start without premium
      setIsPremium(false);

      await initializeUserData(userId);
      await AsyncStorage.setItem(`onboarding_completed_${userId}`, "true");

      setUser(newUser);
      return { success: true };
    } catch (error) {
      console.error("Signup error:", error);
      return { success: false, error: "Signup failed. Please try again." };
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    try {
      await SecureStore.deleteItemAsync("auth_token");
      await SecureStore.deleteItemAsync("user_data");
      await SecureStore.deleteItemAsync("is_admin");
      setUser(null);
      setIsPremium(false);
      setShowOnboarding(false);
      router.replace("/auth");
    } catch (error) {
      console.error("Logout error:", error);
    }
  };

  const completeOnboarding = async () => {
    if (user) {
      await AsyncStorage.setItem(`onboarding_completed_${user.id}`, "true");
      setShowOnboarding(false);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        isPremium,
        login,
        signup,
        logout,
        showOnboarding,
        completeOnboarding,
        refreshPremiumStatus,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuthContext() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuthContext must be used within AuthProvider");
  }
  return context;
}

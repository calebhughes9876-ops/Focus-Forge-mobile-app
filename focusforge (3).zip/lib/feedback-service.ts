import AsyncStorage from "@react-native-async-storage/async-storage";
import * as SecureStore from "expo-secure-store";

export type FeedbackType = "bug" | "feature" | "improvement" | "other";
export type FeedbackStatus = "submitted" | "reviewing" | "in-progress" | "resolved" | "wontfix";

export interface Feedback {
  id: string;
  type: FeedbackType;
  title: string;
  description: string;
  status: FeedbackStatus;
  priority: "low" | "medium" | "high" | "critical";
  userId?: string;
  email?: string;
  attachments?: string[];
  createdAt: string;
  updatedAt: string;
  response?: string;
  votes: number;
}

export async function submitFeedback(
  type: FeedbackType,
  title: string,
  description: string,
  email?: string,
  priority: "low" | "medium" | "high" | "critical" = "medium"
): Promise<{ success: boolean; feedbackId?: string; error?: string }> {
  try {
    const feedbackId = `feedback_${Date.now()}`;
    const userId = await SecureStore.getItemAsync("user_id");

    const feedback: Feedback = {
      id: feedbackId,
      type,
      title,
      description,
      status: "submitted",
      priority,
      userId: userId || undefined,
      email: email || undefined,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      votes: 0,
    };

    // Store locally
    const feedbackList = await AsyncStorage.getItem("user_feedback");
    const list = feedbackList ? JSON.parse(feedbackList) : [];
    list.push(feedback);
    await AsyncStorage.setItem("user_feedback", JSON.stringify(list));

    // In production, send to backend
    console.log("Feedback submitted:", feedback);

    return { success: true, feedbackId };
  } catch (error) {
    console.error("Error submitting feedback:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Failed to submit feedback",
    };
  }
}

export async function getUserFeedback(): Promise<Feedback[]> {
  try {
    const feedbackList = await AsyncStorage.getItem("user_feedback");
    return feedbackList ? JSON.parse(feedbackList) : [];
  } catch (error) {
    console.error("Error fetching feedback:", error);
    return [];
  }
}

export async function getFeedbackById(feedbackId: string): Promise<Feedback | null> {
  try {
    const feedbackList = await getUserFeedback();
    return feedbackList.find(f => f.id === feedbackId) || null;
  } catch (error) {
    console.error("Error fetching feedback:", error);
    return null;
  }
}

export async function updateFeedbackStatus(
  feedbackId: string,
  status: FeedbackStatus,
  response?: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const feedbackList = await getUserFeedback();
    const feedback = feedbackList.find(f => f.id === feedbackId);

    if (!feedback) {
      return { success: false, error: "Feedback not found" };
    }

    feedback.status = status;
    feedback.updatedAt = new Date().toISOString();
    if (response) {
      feedback.response = response;
    }

    await AsyncStorage.setItem("user_feedback", JSON.stringify(feedbackList));

    return { success: true };
  } catch (error) {
    console.error("Error updating feedback:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Failed to update feedback",
    };
  }
}

export async function voteFeedback(feedbackId: string): Promise<{ success: boolean; error?: string }> {
  try {
    const feedbackList = await getUserFeedback();
    const feedback = feedbackList.find(f => f.id === feedbackId);

    if (!feedback) {
      return { success: false, error: "Feedback not found" };
    }

    feedback.votes += 1;
    await AsyncStorage.setItem("user_feedback", JSON.stringify(feedbackList));

    return { success: true };
  } catch (error) {
    console.error("Error voting feedback:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Failed to vote",
    };
  }
}

export async function deleteFeedback(feedbackId: string): Promise<{ success: boolean; error?: string }> {
  try {
    const feedbackList = await getUserFeedback();
    const filtered = feedbackList.filter(f => f.id !== feedbackId);
    await AsyncStorage.setItem("user_feedback", JSON.stringify(filtered));

    return { success: true };
  } catch (error) {
    console.error("Error deleting feedback:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Failed to delete feedback",
    };
  }
}

export async function getFeedbackStats(): Promise<{
  total: number;
  byType: Record<FeedbackType, number>;
  byStatus: Record<FeedbackStatus, number>;
  byPriority: Record<string, number>;
}> {
  try {
    const feedbackList = await getUserFeedback();

    const stats = {
      total: feedbackList.length,
      byType: {
        bug: 0,
        feature: 0,
        improvement: 0,
        other: 0,
      },
      byStatus: {
        submitted: 0,
        reviewing: 0,
        "in-progress": 0,
        resolved: 0,
        wontfix: 0,
      },
      byPriority: {
        low: 0,
        medium: 0,
        high: 0,
        critical: 0,
      },
    };

    feedbackList.forEach(feedback => {
      stats.byType[feedback.type]++;
      stats.byStatus[feedback.status]++;
      stats.byPriority[feedback.priority]++;
    });

    return stats;
  } catch (error) {
    console.error("Error getting feedback stats:", error);
    return {
      total: 0,
      byType: { bug: 0, feature: 0, improvement: 0, other: 0 },
      byStatus: { submitted: 0, reviewing: 0, "in-progress": 0, resolved: 0, wontfix: 0 },
      byPriority: { low: 0, medium: 0, high: 0, critical: 0 },
    };
  }
}

export async function exportFeedbackAsJSON(): Promise<string> {
  try {
    const feedbackList = await getUserFeedback();
    return JSON.stringify(feedbackList, null, 2);
  } catch (error) {
    console.error("Error exporting feedback:", error);
    return "[]";
  }
}

import AsyncStorage from "@react-native-async-storage/async-storage";

export type MoodTag = "locked-in" | "steady" | "distracted" | "burned-out";

export interface Mission {
  id: string;
  title: string;
  completedToday: boolean;
  dueDate: string;
  category?: string;
  minutesTarget?: number;
  dueHour?: number;
  dueMinute?: number;
  note?: string;
  xpReward?: number;
  status?: "missed" | "completed";
}

export interface SessionHistory {
  date: string;
  duration: number;
  xpEarned: number;
  mood?: MoodTag;
  reflection?: string;
  missionId?: string;
  missionTitle?: string;
  shieldPresetId?: string;
  interruptionsAvoided?: number;
}

export interface Challenge {
  id: string;
  name: string;
  description: string;
  completed: boolean;
  currentHours?: number;
  targetHours?: number;
  title?: string;
  userPosition?: number;
  members?: number;
  prize?: string;
  premium?: boolean;
}

export interface Settings {
  theme: "light" | "dark";
  notifications?: boolean;
  dailyReminders?: boolean;
  missionDeadlines?: boolean;
  streakWarnings?: boolean;
  breakReminders?: boolean;
  weeklyReview?: boolean;
  dailyReminder?: string;
}

export interface BlockedApp {
  packageName: string;
  name: string;
  blocked: boolean;
}

export interface ShieldPreset {
  id: string;
  name: string;
  blockedApps: string[];
  allowedApps: string[];
  strictness: "light" | "medium" | "strict";
  mode?: string;
  listMode?: string;
  allowBreaks?: boolean;
  apps?: BlockedApp[];
}

export interface SessionRecord {
  date: string;
  duration: number;
  xpEarned: number;
  label: string;
  missionId: string | null;
  missionTitle: string | null;
  mood: MoodTag;
  reflection: string;
  shieldPresetId: string | null;
  interruptionsAvoided: number;
}

export interface FocusForgeData {
  streak: number;
  focusScoreAverage: number;
  missions: Mission[];
  totalSessions: number;
  totalFocusHours: number;
  rank?: string;
  completedSessions?: number;
  sessionHistory?: SessionHistory[];
  dailyGoalMinutes?: number;
  distractionTimeSavedMinutes?: number;
  recoveryMinutesEarned?: number;
  challengeBoard?: Challenge[];
  settings?: Settings;
  shieldPresets?: ShieldPreset[];
  xp?: number;
}

const DEFAULT_DATA: FocusForgeData = {
  streak: 0,
  focusScoreAverage: 0,
  missions: [],
  totalSessions: 0,
  totalFocusHours: 0,
  rank: "Beginner",
  completedSessions: 0,
  sessionHistory: [],
  dailyGoalMinutes: 120,
  distractionTimeSavedMinutes: 0,
  recoveryMinutesEarned: 0,
  challengeBoard: [],
  settings: {
    theme: "dark",
    notifications: true,
    dailyReminders: true,
    missionDeadlines: true,
    streakWarnings: true,
    breakReminders: true,
    weeklyReview: true,
    dailyReminder: "09:00",
  },
  shieldPresets: [
    {
      id: "default",
      name: "Default Shield",
      blockedApps: ["Instagram", "TikTok", "Twitter"],
      allowedApps: ["Messages", "Phone", "Maps"],
      strictness: "medium",
      apps: [
        { packageName: "com.instagram", name: "Instagram", blocked: true },
        { packageName: "com.tiktok", name: "TikTok", blocked: true },
        { packageName: "com.twitter", name: "Twitter", blocked: true },
        { packageName: "com.sms", name: "Messages", blocked: false },
        { packageName: "com.phone", name: "Phone", blocked: false },
        { packageName: "com.maps", name: "Maps", blocked: false },
      ],
    },
  ],
  xp: 0,
};

export async function loadFocusData(userId: string): Promise<FocusForgeData> {
  try {
    const key = `focusforge_data_${userId}`;
    const stored = await AsyncStorage.getItem(key);
    if (stored) {
      const parsed = JSON.parse(stored);
      // Normalize data to ensure all v3 fields exist
      return normalizeFocusData(parsed);
    }
    return DEFAULT_DATA;
  } catch (error) {
    console.log("Error loading focus data:", error);
    return DEFAULT_DATA;
  }
}

export function normalizeFocusData(raw: any): FocusForgeData {
  return {
    streak: raw.streak ?? 0,
    focusScoreAverage: raw.focusScoreAverage ?? 0,
    missions: Array.isArray(raw.missions) ? raw.missions : [],
    totalSessions: raw.totalSessions ?? 0,
    totalFocusHours: raw.totalFocusHours ?? 0,
    rank: raw.rank ?? "Beginner",
    completedSessions: raw.completedSessions ?? 0,
    sessionHistory: Array.isArray(raw.sessionHistory) ? raw.sessionHistory : [],
    dailyGoalMinutes: raw.dailyGoalMinutes ?? 120,
    distractionTimeSavedMinutes: raw.distractionTimeSavedMinutes ?? 0,
    recoveryMinutesEarned: raw.recoveryMinutesEarned ?? 0,
    challengeBoard: Array.isArray(raw.challengeBoard) ? raw.challengeBoard : [],
    settings: raw.settings ?? DEFAULT_DATA.settings,
    shieldPresets: Array.isArray(raw.shieldPresets) ? raw.shieldPresets : DEFAULT_DATA.shieldPresets,
    xp: raw.xp ?? 0,
  };
}

export async function saveFocusData(userId: string, data: FocusForgeData): Promise<void> {
  try {
    const key = `focusforge_data_${userId}`;
    await AsyncStorage.setItem(key, JSON.stringify(data));
  } catch (error) {
    console.log("Error saving focus data:", error);
  }
}

export function buildWeeklyFocusData(sessionHistory: SessionHistory[] = []): number[] {
  const weekData = [0, 0, 0, 0, 0, 0, 0];
  const today = new Date();

  sessionHistory.forEach((session) => {
    const sessionDate = new Date(session.date);
    const dayDiff = Math.floor((today.getTime() - sessionDate.getTime()) / (1000 * 60 * 60 * 24));
    if (dayDiff >= 0 && dayDiff < 7) {
      weekData[6 - dayDiff] += session.duration;
    }
  });

  return weekData;
}

export function calculateLongestStreak(sessionHistory: SessionHistory[] = []): number {
  if (sessionHistory.length === 0) return 0;

  let longest = 1;
  let current = 1;
  const sortedDates = sessionHistory
    .map((s) => new Date(s.date).toDateString())
    .filter((v, i, a) => a.indexOf(v) === i)
    .sort((a, b) => new Date(b).getTime() - new Date(a).getTime());

  for (let i = 1; i < sortedDates.length; i++) {
    const prevDate = new Date(sortedDates[i - 1]);
    const currDate = new Date(sortedDates[i]);
    const dayDiff = Math.floor((prevDate.getTime() - currDate.getTime()) / (1000 * 60 * 60 * 24));

    if (dayDiff === 1) {
      current++;
      longest = Math.max(longest, current);
    } else {
      current = 1;
    }
  }

  return longest;
}

export function calculateMissionCompletionRate(missions: Mission[] = []): number {
  if (missions.length === 0) return 0;
  const completed = missions.filter((m) => m.completedToday).length;
  return Math.round((completed / missions.length) * 100);
}

export function calculateTodayFocusMinutes(sessionHistory: SessionHistory[] = []): number {
  const today = new Date().toDateString();
  return sessionHistory
    .filter((session) => new Date(session.date).toDateString() === today)
    .reduce((total, session) => total + session.duration, 0);
}

export function getActiveShieldPreset(data: FocusForgeData): ShieldPreset {
  // Return the first shield preset or a default
  if (data.shieldPresets && data.shieldPresets.length > 0) {
    return data.shieldPresets[0];
  }
  return {
    id: "default",
    name: "Default Shield",
    blockedApps: ["Instagram", "TikTok", "Twitter"],
    allowedApps: ["Messages", "Phone", "Maps"],
    strictness: "medium",
    apps: [
      { packageName: "com.instagram", name: "Instagram", blocked: true },
      { packageName: "com.tiktok", name: "TikTok", blocked: true },
      { packageName: "com.twitter", name: "Twitter", blocked: true },
      { packageName: "com.sms", name: "Messages", blocked: false },
      { packageName: "com.phone", name: "Phone", blocked: false },
      { packageName: "com.maps", name: "Maps", blocked: false },
    ],
  };
}

export function buildSessionRecord(params: {
  duration: number;
  xpEarned: number;
  label: string;
  missionId: string | null;
  missionTitle: string | null;
  mood: MoodTag;
  reflection: string;
  shieldPresetId: string | null;
  interruptionsAvoided: number;
}): SessionRecord {
  return {
    date: new Date().toISOString(),
    duration: params.duration,
    xpEarned: params.xpEarned,
    label: params.label,
    missionId: params.missionId,
    missionTitle: params.missionTitle,
    mood: params.mood,
    reflection: params.reflection,
    shieldPresetId: params.shieldPresetId,
    interruptionsAvoided: params.interruptionsAvoided,
  };
}

export function applyCompletedSession(data: FocusForgeData, session: SessionRecord): FocusForgeData {
  const today = new Date().toDateString();
  const lastSessionDate = data.sessionHistory?.[0]?.date;
  const lastSessionDateString = lastSessionDate ? new Date(lastSessionDate).toDateString() : null;

  // Calculate new streak
  let newStreak = data.streak ?? 0;
  if (lastSessionDateString === today) {
    // Session on same day, keep streak
    newStreak = data.streak ?? 0;
  } else if (lastSessionDateString) {
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    if (lastSessionDateString === yesterday.toDateString()) {
      // Session on consecutive day, increment streak
      newStreak = (data.streak ?? 0) + 1;
    } else {
      // Gap in sessions, reset streak
      newStreak = 1;
    }
  } else {
    // First session
    newStreak = 1;
  }

  // Calculate new XP and rank
  const newXp = (data.xp ?? 0) + session.xpEarned;
  let newRank = "Beginner";
  if (newXp >= 250) newRank = "Elite";
  else if (newXp >= 100) newRank = "Focused";
  else newRank = "Beginner";

  // Update session history
  const newSessionHistory = [
    {
      date: session.date,
      duration: session.duration,
      xpEarned: session.xpEarned,
      mood: session.mood,
      reflection: session.reflection,
      missionId: session.missionId ?? undefined,
      missionTitle: session.missionTitle ?? undefined,
      shieldPresetId: session.shieldPresetId ?? undefined,
      interruptionsAvoided: session.interruptionsAvoided,
    },
    ...(data.sessionHistory ?? []),
  ];

  // Calculate total focus hours
  const totalMinutes = newSessionHistory.reduce((sum, s) => sum + s.duration, 0);
  const newTotalFocusHours = Math.round(totalMinutes / 60);

  // Update missions if applicable
  let updatedMissions = data.missions ?? [];
  if (session.missionId) {
    updatedMissions = updatedMissions.map((m) =>
      m.id === session.missionId ? { ...m, completedToday: true } : m
    );
  }

  return {
    ...data,
    streak: newStreak,
    xp: newXp,
    rank: newRank,
    completedSessions: (data.completedSessions ?? 0) + 1,
    totalFocusHours: newTotalFocusHours,
    sessionHistory: newSessionHistory,
    missions: updatedMissions,
    distractionTimeSavedMinutes: (data.distractionTimeSavedMinutes ?? 0) + session.interruptionsAvoided,
  };
}

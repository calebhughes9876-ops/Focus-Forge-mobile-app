import * as Notifications from "expo-notifications";
// import * as Device from "expo-device";
import AsyncStorage from "@react-native-async-storage/async-storage";

// Configure notification handler
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

export async function registerForPushNotifications() {
  // Device check removed for web compatibility

  try {
    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;

    if (existingStatus !== "granted") {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }

    if (finalStatus !== "granted") {
      console.log("Failed to get push notification permissions");
      return;
    }

    console.log("Push notifications enabled");
    return true;
  } catch (error) {
    console.error("Error registering for push notifications:", error);
  }
}

export async function scheduleDailyReminder(hour: number = 9, minute: number = 0) {
  try {
    // Cancel existing reminders
    await Notifications.cancelAllScheduledNotificationsAsync();

    // Schedule daily reminder at specific time
    await Notifications.scheduleNotificationAsync({
      content: {
        title: "🔥 Time to Focus",
        body: "Your daily focus mission is waiting. Build your streak!",
        sound: "default",
        badge: 1,
      },
      trigger: {
        type: "daily",
        hour,
        minute,
      } as any, // Type assertion to avoid strict typing issues
    });

    console.log(`Daily reminder scheduled for ${hour}:${minute.toString().padStart(2, "0")}`);
  } catch (error) {
    console.error("Error scheduling daily reminder:", error);
  }
}

export async function scheduleDeadlineAlert(missionName: string, minutesFromNow: number) {
  try {
    await Notifications.scheduleNotificationAsync({
      content: {
        title: "⏰ Mission Deadline",
        body: `"${missionName}" deadline is in ${minutesFromNow} minutes!`,
        sound: "default",
        badge: 1,
      },
      trigger: {
        seconds: Math.max(minutesFromNow * 60, 1),
      } as any,
    });

    console.log(`Deadline alert scheduled for ${missionName}`);
  } catch (error) {
    console.error("Error scheduling deadline alert:", error);
  }
}

export async function scheduleStreakLossWarning() {
  try {
    // Schedule warning for 11 PM if no session completed today
    await Notifications.scheduleNotificationAsync({
      content: {
        title: "⚠️ Streak at Risk",
        body: "You haven't completed your focus mission today. Don't lose your streak!",
        sound: "default",
        badge: 1,
      },
      trigger: {
        type: "daily",
        hour: 23,
        minute: 0,
      } as any,
    });

    console.log("Streak loss warning scheduled for 11 PM");
  } catch (error) {
    console.error("Error scheduling streak loss warning:", error);
  }
}

export async function sendPremiumActivationNotification() {
  try {
    await Notifications.scheduleNotificationAsync({
      content: {
        title: "🎉 Premium Activated",
        body: "Welcome to FocusForge Premium! Unlock the AI Coach now.",
        sound: "default",
        badge: 1,
      },
      trigger: {
        seconds: 1,
      } as any,
    });
  } catch (error) {
    console.error("Error sending premium notification:", error);
  }
}

export async function sendSessionCompletionNotification(xpEarned: number, streakDays: number) {
  try {
    await Notifications.scheduleNotificationAsync({
      content: {
        title: "✅ Session Complete!",
        body: `+${xpEarned} XP | 🔥 ${streakDays} day streak!`,
        sound: "default",
        badge: 1,
      },
      trigger: {
        seconds: 1,
      } as any,
    });
  } catch (error) {
    console.error("Error sending completion notification:", error);
  }
}

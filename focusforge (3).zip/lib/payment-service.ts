import * as SecureStore from "expo-secure-store";
import AsyncStorage from "@react-native-async-storage/async-storage";

interface SubscriptionPlan {
  id: string;
  name: string;
  price: number;
  currency: string;
  period: "monthly" | "yearly";
  description: string;
}

export const SUBSCRIPTION_PLANS: Record<string, SubscriptionPlan> = {
  monthly: {
    id: "price_monthly_focusforge",
    name: "Monthly",
    price: 5.99,
    currency: "USD",
    period: "monthly",
    description: "Full access to all premium features",
  },
  yearly: {
    id: "price_yearly_focusforge",
    name: "Yearly",
    price: 49.99,
    currency: "USD",
    period: "yearly",
    description: "Full access + 30% savings",
  },
};

export async function initializePayments() {
  try {
    // In production, initialize Stripe SDK here
    // const stripe = require("@stripe/stripe-react-native").useStripe();
    console.log("Payment system initialized");
    return true;
  } catch (error) {
    console.error("Error initializing payments:", error);
    return false;
  }
}

export async function processPayment(
  planId: string,
  paymentMethod: "stripe" | "paypal" | "applepay"
) {
  try {
    const plan = SUBSCRIPTION_PLANS[planId];
    if (!plan) {
      throw new Error("Invalid plan");
    }

    // Simulate payment processing
    console.log(`Processing ${paymentMethod} payment for ${plan.name} plan: $${plan.price}`);

    // In production, call Stripe API or payment processor
    // const result = await stripe.confirmPayment(...)

    // For now, simulate success
    const transactionId = `txn_${Date.now()}`;
    const expiresAt = new Date();

    if (plan.period === "monthly") {
      expiresAt.setMonth(expiresAt.getMonth() + 1);
    } else {
      expiresAt.setFullYear(expiresAt.getFullYear() + 1);
    }

    // Store subscription data
    await SecureStore.setItemAsync("premium_active", "true");
    await SecureStore.setItemAsync("premium_expires_at", expiresAt.toISOString());
    await SecureStore.setItemAsync("subscription_plan", planId);
    await SecureStore.setItemAsync("payment_method", paymentMethod);
    await SecureStore.setItemAsync("transaction_id", transactionId);

    // Store transaction history
    const transactions = await AsyncStorage.getItem("transaction_history");
    const history = transactions ? JSON.parse(transactions) : [];
    history.push({
      id: transactionId,
      plan: planId,
      amount: plan.price,
      currency: plan.currency,
      method: paymentMethod,
      date: new Date().toISOString(),
      status: "completed",
    });
    await AsyncStorage.setItem("transaction_history", JSON.stringify(history));

    return {
      success: true,
      transactionId,
      expiresAt,
      plan,
    };
  } catch (error) {
    console.error("Payment error:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Payment failed",
    };
  }
}

export async function verifySubscription() {
  try {
    const premiumActive = await SecureStore.getItemAsync("premium_active");
    const expiresAt = await SecureStore.getItemAsync("premium_expires_at");

    if (premiumActive !== "true" || !expiresAt) {
      return { isPremium: false, expiresAt: null };
    }

    const expireDate = new Date(expiresAt);
    const now = new Date();

    if (expireDate <= now) {
      // Subscription expired
      await SecureStore.deleteItemAsync("premium_active");
      return { isPremium: false, expiresAt: null };
    }

    return {
      isPremium: true,
      expiresAt: expireDate,
      daysRemaining: Math.ceil((expireDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)),
    };
  } catch (error) {
    console.error("Error verifying subscription:", error);
    return { isPremium: false, expiresAt: null };
  }
}

export async function cancelSubscription() {
  try {
    // In production, call Stripe API to cancel subscription
    // await stripe.cancelSubscription(subscriptionId)

    await SecureStore.deleteItemAsync("premium_active");
    await SecureStore.deleteItemAsync("premium_expires_at");
    await SecureStore.deleteItemAsync("subscription_plan");
    await SecureStore.deleteItemAsync("payment_method");

    console.log("Subscription cancelled");
    return { success: true };
  } catch (error) {
    console.error("Error cancelling subscription:", error);
    return { success: false, error: error instanceof Error ? error.message : "Cancellation failed" };
  }
}

export async function getTransactionHistory() {
  try {
    const transactions = await AsyncStorage.getItem("transaction_history");
    return transactions ? JSON.parse(transactions) : [];
  } catch (error) {
    console.error("Error fetching transaction history:", error);
    return [];
  }
}

export async function getSubscriptionStatus() {
  try {
    const plan = await SecureStore.getItemAsync("subscription_plan");
    const verification = await verifySubscription();

    return {
      ...verification,
      plan: plan || null,
      paymentMethod: await SecureStore.getItemAsync("payment_method"),
    };
  } catch (error) {
    console.error("Error getting subscription status:", error);
    return { isPremium: false, expiresAt: null, plan: null, paymentMethod: null };
  }
}

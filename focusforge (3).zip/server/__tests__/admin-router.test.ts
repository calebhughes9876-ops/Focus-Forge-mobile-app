import { describe, it, expect } from "vitest";
import { adminRouter } from "../admin-router";

describe("Admin Router", () => {
  describe("adminLogin", () => {
    it("should accept valid admin credentials", async () => {
      const caller = adminRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      const result = await caller.adminLogin({
        email: "admin@focusforge.app",
        password: "admin123",
      });

      expect(result.success).toBe(true);
      expect(result.token).toBeDefined();
    });

    it("should reject invalid email", async () => {
      const caller = adminRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      try {
        await caller.adminLogin({
          email: "wrong@example.com",
          password: "admin123",
        });
        expect.fail("Should have thrown an error");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });

    it("should reject invalid password", async () => {
      const caller = adminRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      try {
        await caller.adminLogin({
          email: "admin@focusforge.app",
          password: "wrongpassword",
        });
        expect.fail("Should have thrown an error");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });
  });

  describe("getDashboardStats", () => {
    it("should return dashboard stats", async () => {
      const caller = adminRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      const result = await caller.getDashboardStats();
      expect(result.success).toBe(true);
      expect(result.stats).toBeDefined();
      expect(result.stats.totalUsers).toBeDefined();
      expect(result.stats.premiumUsers).toBeDefined();
    });
  });

  describe("grantPremium", () => {
    it("should accept valid user ID", async () => {
      const caller = adminRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      try {
        const result = await caller.grantPremium({
          userId: 1,
          durationDays: 365,
        });
        // May fail if user doesn't exist, but that's okay for this test
        expect(result).toBeDefined();
      } catch (error) {
        // Expected if user doesn't exist
        expect(error).toBeDefined();
      }
    });
  });

  describe("enableTestMode", () => {
    it("should accept valid user ID", async () => {
      const caller = adminRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      try {
        const result = await caller.enableTestMode({ userId: 1 });
        expect(result).toBeDefined();
      } catch (error) {
        // Expected if user doesn't exist
        expect(error).toBeDefined();
      }
    });
  });

  describe("resetUserStats", () => {
    it("should accept valid user ID", async () => {
      const caller = adminRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      try {
        const result = await caller.resetUserStats({ userId: 1 });
        expect(result).toBeDefined();
      } catch (error) {
        // Expected if user doesn't exist
        expect(error).toBeDefined();
      }
    });
  });
});

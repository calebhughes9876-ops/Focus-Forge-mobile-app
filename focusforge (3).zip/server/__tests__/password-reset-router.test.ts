import { describe, it, expect } from "vitest";
import { passwordResetRouter } from "../password-reset-router";

describe("Password Reset Router", () => {
  describe("requestReset", () => {
    it("should accept valid email", async () => {
      const caller = passwordResetRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      const result = await caller.requestReset({ email: "test@example.com" });
      expect(result.success).toBe(true);
      expect(result.message).toBeDefined();
    });

    it("should reject invalid email", async () => {
      const caller = passwordResetRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      try {
        await caller.requestReset({ email: "invalid-email" });
        expect.fail("Should have thrown an error");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });
  });

  describe("verifyReset", () => {
    it("should reject invalid token", async () => {
      const caller = passwordResetRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      try {
        await caller.verifyReset({
          email: "test@example.com",
          token: "invalid_token",
          otp: "123456",
        });
        expect.fail("Should have thrown an error");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });

    it("should reject invalid OTP format", async () => {
      const caller = passwordResetRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      try {
        await caller.verifyReset({
          email: "test@example.com",
          token: "valid_token",
          otp: "12345", // Only 5 digits
        });
        expect.fail("Should have thrown an error");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });
  });

  describe("resetPassword", () => {
    it("should reject mismatched passwords", async () => {
      const caller = passwordResetRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      try {
        await caller.resetPassword({
          email: "test@example.com",
          token: "valid_token",
          newPassword: "password123",
          confirmPassword: "password456",
        });
        expect.fail("Should have thrown an error");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });

    it("should reject short password", async () => {
      const caller = passwordResetRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      try {
        await caller.resetPassword({
          email: "test@example.com",
          token: "valid_token",
          newPassword: "pass",
          confirmPassword: "pass",
        });
        expect.fail("Should have thrown an error");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });
  });

  describe("cleanupExpiredTokens", () => {
    it("should complete cleanup", async () => {
      const caller = passwordResetRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      const result = await caller.cleanupExpiredTokens();
      expect(result.success).toBe(true);
    });
  });
});

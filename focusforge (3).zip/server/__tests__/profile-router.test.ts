import { describe, it, expect } from "vitest";
import { profileRouter } from "../profile-router";

describe("Profile Router", () => {
  describe("getProfile", () => {
    it("should return null for non-existent profile", async () => {
      const caller = profileRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      const result = await caller.getProfile({ userId: 99999 });
      expect(result).toBeNull();
    });
  });

  describe("updateProfile", () => {
    it("should require authentication", async () => {
      const caller = profileRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      try {
        await caller.updateProfile({
          username: "testuser",
          bio: "Test bio",
        });
        expect.fail("Should have thrown an error");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });
  });

  describe("searchUsers", () => {
    it("should accept valid search query", async () => {
      const caller = profileRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      const result = await caller.searchUsers({ query: "test" });
      expect(Array.isArray(result)).toBe(true);
    });

    it("should reject empty query", async () => {
      const caller = profileRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      try {
        await caller.searchUsers({ query: "" });
        expect.fail("Should have thrown an error");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });
  });

  describe("getLeaderboard", () => {
    it("should return leaderboard", async () => {
      const caller = profileRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      const result = await caller.getLeaderboard({ limit: 10 });
      expect(Array.isArray(result)).toBe(true);
    });
  });

  describe("getFriends", () => {
    it("should require authentication", async () => {
      const caller = profileRouter.createCaller({
        user: null,
        req: {} as any,
        res: {} as any,
      });

      try {
        await caller.getFriends();
        expect.fail("Should have thrown an error");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });
  });
});

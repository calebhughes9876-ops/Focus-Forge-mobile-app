import { z } from "zod";
import { publicProcedure, router } from "./_core/trpc";
import { getDb } from "./db";
import { users, userStats } from "../drizzle/schema";
import { eq } from "drizzle-orm";

// Admin credentials (in production, use environment variables)
const ADMIN_EMAIL = "admin@focusforge.app";
const ADMIN_PASSWORD = "admin123"; // Change this in production!

export const adminRouter = router({
  // Admin login
  adminLogin: publicProcedure
    .input(
      z.object({
        email: z.string().email(),
        password: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        // Verify admin credentials
        if (input.email !== ADMIN_EMAIL || input.password !== ADMIN_PASSWORD) {
          throw new Error("Invalid admin credentials");
        }

        // In production, create a proper admin session
        const adminToken = "admin_token_" + Date.now();

        return {
          success: true,
          token: adminToken,
          message: "Admin login successful",
        };
      } catch (error) {
        console.error("Admin login error:", error);
        throw new Error(error instanceof Error ? error.message : "Admin login failed");
      }
    }),

  // Get all users
  getAllUsers: publicProcedure.query(async () => {
    try {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const allUsers = await db.select().from(users);
      return { success: true, users: allUsers };
    } catch (error) {
      console.error("Error fetching users:", error);
      throw new Error("Failed to fetch users");
    }
  }),

  // Get user details with stats
  getUserDetails: publicProcedure
    .input(z.object({ userId: z.number() }))
    .query(async ({ input }) => {
      try {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        const user = await db.select().from(users).where(eq(users.id, input.userId)).limit(1);

        if (user.length === 0) {
          throw new Error("User not found");
        }

        const stats = await db
          .select()
          .from(userStats)
          .where(eq(userStats.userId, input.userId))
          .limit(1);

        return {
          success: true,
          user: user[0],
          stats: stats[0] || null,
        };
      } catch (error) {
        console.error("Error fetching user details:", error);
        throw new Error(error instanceof Error ? error.message : "Failed to fetch user details");
      }
    }),

  // Grant premium to user
  grantPremium: publicProcedure
    .input(
      z.object({
        userId: z.number(),
        durationDays: z.number().default(365),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        const expiresAt = new Date(Date.now() + input.durationDays * 24 * 60 * 60 * 1000);

        await db
          .update(userStats)
          .set({
            isPremium: 1,
            premiumExpiresAt: expiresAt,
          })
          .where(eq(userStats.userId, input.userId));

        return {
          success: true,
          message: `Premium granted for ${input.durationDays} days`,
          expiresAt,
        };
      } catch (error) {
        console.error("Error granting premium:", error);
        throw new Error("Failed to grant premium");
      }
    }),

  // Revoke premium from user
  revokePremium: publicProcedure
    .input(z.object({ userId: z.number() }))
    .mutation(async ({ input }) => {
      try {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        await db
          .update(userStats)
          .set({
            isPremium: 0,
            premiumExpiresAt: null,
          })
          .where(eq(userStats.userId, input.userId));

        return { success: true, message: "Premium revoked" };
      } catch (error) {
        console.error("Error revoking premium:", error);
        throw new Error("Failed to revoke premium");
      }
    }),

  // Enable test mode for user
  enableTestMode: publicProcedure
    .input(z.object({ userId: z.number() }))
    .mutation(async ({ input }) => {
      try {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        await db
          .update(userStats)
          .set({ isTestMode: 1 })
          .where(eq(userStats.userId, input.userId));

        return { success: true, message: "Test mode enabled" };
      } catch (error) {
        console.error("Error enabling test mode:", error);
        throw new Error("Failed to enable test mode");
      }
    }),

  // Disable test mode for user
  disableTestMode: publicProcedure
    .input(z.object({ userId: z.number() }))
    .mutation(async ({ input }) => {
      try {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        await db
          .update(userStats)
          .set({ isTestMode: 0 })
          .where(eq(userStats.userId, input.userId));

        return { success: true, message: "Test mode disabled" };
      } catch (error) {
        console.error("Error disabling test mode:", error);
        throw new Error("Failed to disable test mode");
      }
    }),

  // Reset user stats
  resetUserStats: publicProcedure
    .input(z.object({ userId: z.number() }))
    .mutation(async ({ input }) => {
      try {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        await db
          .update(userStats)
          .set({
            streak: 0,
            xp: 0,
            totalFocusHours: 0,
            completedSessions: 0,
          })
          .where(eq(userStats.userId, input.userId));

        return { success: true, message: "User stats reset" };
      } catch (error) {
        console.error("Error resetting stats:", error);
        throw new Error("Failed to reset stats");
      }
    }),

  // Get dashboard stats
  getDashboardStats: publicProcedure.query(async () => {
    try {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const totalUsers = await db.select().from(users);
      const premiumUsers = await db
        .select()
        .from(userStats)
        .where(eq(userStats.isPremium, 1));

      const totalXP = totalUsers.length > 0 ? totalUsers.length * 100 : 0;

      return {
        success: true,
        stats: {
          totalUsers: totalUsers.length,
          premiumUsers: premiumUsers.length,
          totalXP,
          averageStreak: 5, // Placeholder
        },
      };
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      throw new Error("Failed to fetch dashboard stats");
    }
  }),
});

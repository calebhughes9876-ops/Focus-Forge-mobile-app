import { z } from "zod";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { getDb } from "./db";
import { feedback } from "../drizzle/schema";
import { eq, desc } from "drizzle-orm";

export const feedbackRouter = router({
  submit: publicProcedure
    .input(
      z.object({
        type: z.enum(["bug", "feature", "improvement", "other"]),
        title: z.string().min(1).max(255),
        description: z.string().min(1).max(1000),
        email: z.string().email().optional(),
        priority: z.enum(["low", "medium", "high", "critical"]).default("medium"),
      })
    )
    .mutation(async ({ input, ctx }) => {
      try {
        const db = await getDb();
        if (!db) throw new Error("Database not available");
        const userId = ctx.user?.id;

        await db.insert(feedback).values({
          userId: userId || undefined,
          type: input.type,
          title: input.title,
          description: input.description,
          email: input.email,
          priority: input.priority,
          status: "submitted",
          votes: 0,
        });

        return {
          success: true,
          feedbackId: Date.now(),
        };
      } catch (error) {
        console.error("Error submitting feedback:", error);
        throw new Error("Failed to submit feedback");
      }
    }),

  list: publicProcedure.query(async () => {
    try {
      const db = await getDb();
      if (!db) return [];
      const feedbackList = await db
        .select()
        .from(feedback)
        .orderBy(desc(feedback.createdAt))
        .limit(100);

      return feedbackList;
    } catch (error) {
      console.error("Error fetching feedback:", error);
      return [];
    }
  }),

  getById: publicProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      try {
        const db = await getDb();
        if (!db) return null;
        const result = await db
          .select()
          .from(feedback)
          .where(eq(feedback.id, input.id))
          .limit(1);

        return result[0] || null;
      } catch (error) {
        console.error("Error fetching feedback:", error);
        return null;
      }
    }),

  updateStatus: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        status: z.enum(["submitted", "reviewing", "in-progress", "resolved", "wontfix"]),
        response: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const db = await getDb();
        if (!db) throw new Error("Database not available");
        await db
          .update(feedback)
          .set({
            status: input.status,
            response: input.response,
            updatedAt: new Date(),
          })
          .where(eq(feedback.id, input.id));

        return { success: true };
      } catch (error) {
        console.error("Error updating feedback:", error);
        throw new Error("Failed to update feedback");
      }
    }),

  vote: publicProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      try {
        const db = await getDb();
        if (!db) throw new Error("Database not available");
        const item = await db
          .select()
          .from(feedback)
          .where(eq(feedback.id, input.id))
          .limit(1);

        if (!item[0]) {
          throw new Error("Feedback not found");
        }

        await db
          .update(feedback)
          .set({
            votes: (item[0].votes || 0) + 1,
            updatedAt: new Date(),
          })
          .where(eq(feedback.id, input.id));

        return { success: true, votes: (item[0].votes || 0) + 1 };
      } catch (error) {
        console.error("Error voting feedback:", error);
        throw new Error("Failed to vote");
      }
    }),

  getStats: publicProcedure.query(async () => {
    try {
      const db = await getDb();
      if (!db) return {
        total: 0,
        byType: { bug: 0, feature: 0, improvement: 0, other: 0 },
        byStatus: { submitted: 0, reviewing: 0, "in-progress": 0, resolved: 0, wontfix: 0 },
      };
      const feedbackList = await db.select().from(feedback);

      const stats = {
        total: feedbackList.length,
        byType: {
          bug: feedbackList.filter((f: any) => f.type === "bug").length,
          feature: feedbackList.filter((f: any) => f.type === "feature").length,
          improvement: feedbackList.filter((f: any) => f.type === "improvement").length,
          other: feedbackList.filter((f: any) => f.type === "other").length,
        },
        byStatus: {
          submitted: feedbackList.filter((f: any) => f.status === "submitted").length,
          reviewing: feedbackList.filter((f: any) => f.status === "reviewing").length,
          "in-progress": feedbackList.filter((f: any) => f.status === "in-progress").length,
          resolved: feedbackList.filter((f: any) => f.status === "resolved").length,
          wontfix: feedbackList.filter((f: any) => f.status === "wontfix").length,
        },
      };

      return stats;
    } catch (error) {
      console.error("Error getting feedback stats:", error);
      return {
        total: 0,
        byType: { bug: 0, feature: 0, improvement: 0, other: 0 },
        byStatus: { submitted: 0, reviewing: 0, "in-progress": 0, resolved: 0, wontfix: 0 },
      };
    }
  }),

  getUserFeedback: publicProcedure.query(async ({ ctx }) => {
    try {
      if (!ctx.user?.id) {
        return [];
      }

      const db = await getDb();
      if (!db) return [];
      const userFeedback = await db
        .select()
        .from(feedback)
        .where(eq(feedback.userId, ctx.user.id))
        .orderBy(desc(feedback.createdAt));

      return userFeedback;
    } catch (error) {
      console.error("Error fetching user feedback:", error);
      return [];
    }
  }),
});

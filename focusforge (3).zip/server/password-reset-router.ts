import { z } from "zod";
import { publicProcedure, router } from "./_core/trpc";
import { getDb } from "./db";
import { passwordResetTokens, users } from "../drizzle/schema";
import { eq, and } from "drizzle-orm";
import crypto from "crypto";

// Helper function to generate reset token
function generateResetToken(): string {
  return crypto.randomBytes(32).toString("hex");
}

// Helper function to generate OTP
function generateOTP(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

export const passwordResetRouter = router({
  // Request password reset
  requestReset: publicProcedure
    .input(z.object({ email: z.string().email() }))
    .mutation(async ({ input }) => {
      try {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        // Check if user exists
        const userResult = await db
          .select()
          .from(users)
          .where(eq(users.email, input.email))
          .limit(1);

        if (userResult.length === 0) {
          // For security, don't reveal if email exists
          return { success: true, message: "If email exists, reset link will be sent" };
        }

        const user = userResult[0];
        const token = generateResetToken();
        const otp = generateOTP();
        const expiresAt = new Date(Date.now() + 15 * 60 * 1000); // 15 minutes

        // Store reset token
        await db.insert(passwordResetTokens).values({
          userId: user.id,
          token,
          email: input.email,
          expiresAt,
        });

        // In production, send email with reset link and OTP
        console.log(`Password reset OTP for ${input.email}: ${otp}`);
        console.log(`Reset token: ${token}`);

        return {
          success: true,
          message: "Password reset email sent",
          // For demo purposes, return OTP (remove in production)
          otp,
        };
      } catch (error) {
        console.error("Error requesting password reset:", error);
        throw new Error("Failed to request password reset");
      }
    }),

  // Verify reset token and OTP
  verifyReset: publicProcedure
    .input(
      z.object({
        email: z.string().email(),
        token: z.string(),
        otp: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        // Find reset token
        const resetTokenResult = await db
          .select()
          .from(passwordResetTokens)
          .where(
            and(
              eq(passwordResetTokens.token, input.token),
              eq(passwordResetTokens.email, input.email)
            )
          )
          .limit(1);

        if (resetTokenResult.length === 0) {
          throw new Error("Invalid reset token");
        }

        const resetToken = resetTokenResult[0];

        // Check if token is expired
        if (new Date() > resetToken.expiresAt) {
          throw new Error("Reset token has expired");
        }

        // Check if token has already been used
        if (resetToken.usedAt) {
          throw new Error("Reset token has already been used");
        }

        // In production, verify OTP against what was sent
        // For now, accept any 6-digit OTP
        if (!/^\d{6}$/.test(input.otp)) {
          throw new Error("Invalid OTP format");
        }

        return { success: true, message: "Reset token verified" };
      } catch (error) {
        console.error("Error verifying reset:", error);
        throw new Error(error instanceof Error ? error.message : "Failed to verify reset");
      }
    }),

  // Reset password
  resetPassword: publicProcedure
    .input(
      z.object({
        email: z.string().email(),
        token: z.string(),
        newPassword: z.string().min(8),
        confirmPassword: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        // Validate passwords match
        if (input.newPassword !== input.confirmPassword) {
          throw new Error("Passwords do not match");
        }

        // Find reset token
        const resetTokenResult = await db
          .select()
          .from(passwordResetTokens)
          .where(
            and(
              eq(passwordResetTokens.token, input.token),
              eq(passwordResetTokens.email, input.email)
            )
          )
          .limit(1);

        if (resetTokenResult.length === 0) {
          throw new Error("Invalid reset token");
        }

        const resetToken = resetTokenResult[0];

        // Check if token is expired
        if (new Date() > resetToken.expiresAt) {
          throw new Error("Reset token has expired");
        }

        // Check if token has already been used
        if (resetToken.usedAt) {
          throw new Error("Reset token has already been used");
        }

        // In production, hash the password before storing
        // For now, we'll just mark the token as used
        // In a real app, you'd update the user's password hash
        // await db
        //   .update(users)
        //   .set({ passwordHash: hashPassword(input.newPassword), updatedAt: new Date() })
        //   .where(eq(users.id, resetToken.userId));

        // Mark token as used
        await db
          .update(passwordResetTokens)
          .set({ usedAt: new Date() })
          .where(eq(passwordResetTokens.id, resetToken.id));

        return { success: true, message: "Password reset successfully" };
      } catch (error) {
        console.error("Error resetting password:", error);
        throw new Error(error instanceof Error ? error.message : "Failed to reset password");
      }
    }),

  // Clean up expired tokens (can be called periodically)
  cleanupExpiredTokens: publicProcedure.mutation(async () => {
    try {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      // Delete expired tokens
      const result = await db
        .delete(passwordResetTokens)
        .where(
          and(
            // Token is expired
            // Note: This comparison might need adjustment based on your DB
            passwordResetTokens.expiresAt
          )
        );

      return { success: true, message: "Cleanup completed" };
    } catch (error) {
      console.error("Error cleaning up tokens:", error);
      throw new Error("Failed to cleanup tokens");
    }
  }),
});

import { z } from "zod";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { getDb } from "./db";
import { userProfiles, friendRequests, friends, users } from "../drizzle/schema";
import { eq, and, or, desc } from "drizzle-orm";

export const profileRouter = router({
  // Get or create user profile
  getProfile: publicProcedure
    .input(z.object({ userId: z.number().optional() }).optional())
    .query(async ({ input, ctx }) => {
      try {
        const db = await getDb();
        if (!db) return null;

        const targetUserId = input?.userId || ctx.user?.id;
        if (!targetUserId) return null;

        const profile = await db
          .select()
          .from(userProfiles)
          .where(eq(userProfiles.userId, targetUserId))
          .limit(1);

        return profile[0] || null;
      } catch (error) {
        console.error("Error fetching profile:", error);
        return null;
      }
    }),

  // Update user profile
  updateProfile: protectedProcedure
    .input(
      z.object({
        username: z.string().min(3).max(50).optional(),
        bio: z.string().max(500).optional(),
        avatar: z.string().url().optional(),
        favoriteMode: z.enum(["15", "25", "45", "90"]).optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      try {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        const userId = ctx.user?.id;
        if (!userId) throw new Error("User not authenticated");

        // Check if profile exists
        const existingProfile = await db
          .select()
          .from(userProfiles)
          .where(eq(userProfiles.userId, userId))
          .limit(1);

        if (existingProfile.length === 0) {
          // Create profile if it doesn't exist
          await db.insert(userProfiles).values({
            userId,
            username: input.username || `user_${userId}`,
            bio: input.bio,
            avatar: input.avatar,
            favoriteMode: input.favoriteMode,
          });
        } else {
          // Update existing profile
          await db
            .update(userProfiles)
            .set({
              username: input.username,
              bio: input.bio,
              avatar: input.avatar,
              favoriteMode: input.favoriteMode,
              updatedAt: new Date(),
            })
            .where(eq(userProfiles.userId, userId));
        }

        return { success: true };
      } catch (error) {
        console.error("Error updating profile:", error);
        throw new Error("Failed to update profile");
      }
    }),

  // Send friend request
  sendFriendRequest: protectedProcedure
    .input(z.object({ receiverId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      try {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        const senderId = ctx.user?.id;
        if (!senderId) throw new Error("User not authenticated");

        if (senderId === input.receiverId) {
          throw new Error("Cannot send friend request to yourself");
        }

        // Check if request already exists
        const existing = await db
          .select()
          .from(friendRequests)
          .where(
            and(
              eq(friendRequests.senderId, senderId),
              eq(friendRequests.receiverId, input.receiverId)
            )
          )
          .limit(1);

        if (existing.length > 0) {
          throw new Error("Friend request already sent");
        }

        await db.insert(friendRequests).values({
          senderId,
          receiverId: input.receiverId,
          status: "pending",
        });

        return { success: true };
      } catch (error) {
        console.error("Error sending friend request:", error);
        throw new Error(error instanceof Error ? error.message : "Failed to send friend request");
      }
    }),

  // Accept friend request
  acceptFriendRequest: protectedProcedure
    .input(z.object({ requestId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      try {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        const userId = ctx.user?.id;
        if (!userId) throw new Error("User not authenticated");

        // Get the friend request
        const request = await db
          .select()
          .from(friendRequests)
          .where(eq(friendRequests.id, input.requestId))
          .limit(1);

        if (request.length === 0) {
          throw new Error("Friend request not found");
        }

        const req = request[0];
        if (req.receiverId !== userId) {
          throw new Error("Unauthorized");
        }

        // Update request status
        await db
          .update(friendRequests)
          .set({ status: "accepted", updatedAt: new Date() })
          .where(eq(friendRequests.id, input.requestId));

        // Create friendship
        await db.insert(friends).values({
          userId1: Math.min(req.senderId, userId),
          userId2: Math.max(req.senderId, userId),
        });

        return { success: true };
      } catch (error) {
        console.error("Error accepting friend request:", error);
        throw new Error("Failed to accept friend request");
      }
    }),

  // Reject friend request
  rejectFriendRequest: protectedProcedure
    .input(z.object({ requestId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      try {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        const userId = ctx.user?.id;
        if (!userId) throw new Error("User not authenticated");

        await db
          .update(friendRequests)
          .set({ status: "rejected", updatedAt: new Date() })
          .where(eq(friendRequests.id, input.requestId));

        return { success: true };
      } catch (error) {
        console.error("Error rejecting friend request:", error);
        throw new Error("Failed to reject friend request");
      }
    }),

  // Get friend requests
  getFriendRequests: protectedProcedure.query(async ({ ctx }) => {
    try {
      const db = await getDb();
      if (!db) return [];

      const userId = ctx.user?.id;
      if (!userId) return [];

      const requests = await db
        .select()
        .from(friendRequests)
        .where(
          and(eq(friendRequests.receiverId, userId), eq(friendRequests.status, "pending"))
        )
        .orderBy(desc(friendRequests.createdAt));

      return requests;
    } catch (error) {
      console.error("Error fetching friend requests:", error);
      return [];
    }
  }),

  // Get friends list
  getFriends: protectedProcedure.query(async ({ ctx }) => {
    try {
      const db = await getDb();
      if (!db) return [];

      const userId = ctx.user?.id;
      if (!userId) return [];

      const friendsList = await db
        .select()
        .from(friends)
        .where(or(eq(friends.userId1, userId), eq(friends.userId2, userId)));

      // Get the friend IDs
      const friendIds = friendsList.map(f => (f.userId1 === userId ? f.userId2 : f.userId1));

      if (friendIds.length === 0) return [];

      // Get friend profiles
      const friendProfiles = await db
        .select()
        .from(userProfiles)
        .where(
          or(
            ...friendIds.map(id => eq(userProfiles.userId, id))
          )
        );

      return friendProfiles;
    } catch (error) {
      console.error("Error fetching friends:", error);
      return [];
    }
  }),

  // Remove friend
  removeFriend: protectedProcedure
    .input(z.object({ friendId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      try {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        const userId = ctx.user?.id;
        if (!userId) throw new Error("User not authenticated");

        await db
          .delete(friends)
          .where(
            or(
              and(eq(friends.userId1, userId), eq(friends.userId2, input.friendId)),
              and(eq(friends.userId1, input.friendId), eq(friends.userId2, userId))
            )
          );

        return { success: true };
      } catch (error) {
        console.error("Error removing friend:", error);
        throw new Error("Failed to remove friend");
      }
    }),

  // Search users
  searchUsers: publicProcedure
    .input(z.object({ query: z.string().min(1).max(50) }))
    .query(async ({ input }) => {
      try {
        const db = await getDb();
        if (!db) return [];

        // Simple search - in production, use full-text search
        const results = await db
          .select()
          .from(userProfiles)
          .limit(10);

        // Filter results client-side
        return results.filter(p => 
          p.username.toLowerCase().includes(input.query.toLowerCase())
        );
      } catch (error) {
        console.error("Error searching users:", error);
        return [];
      }
    }),

  // Get leaderboard
  getLeaderboard: publicProcedure
    .input(z.object({ limit: z.number().default(10) }))
    .query(async ({ input }) => {
      try {
        const db = await getDb();
        if (!db) return [];

        const leaderboard = await db
          .select()
          .from(userProfiles)
          .orderBy(desc(userProfiles.longestStreak))
          .limit(10);

        return leaderboard;
      } catch (error) {
        console.error("Error fetching leaderboard:", error);
        return [];
      }
    }),
});

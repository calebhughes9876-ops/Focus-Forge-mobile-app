import { describe, it, expect, beforeEach, vi } from "vitest";
import AsyncStorage from "@react-native-async-storage/async-storage";

// Mock AsyncStorage
vi.mock("@react-native-async-storage/async-storage", () => ({
  default: {
    getItem: vi.fn(),
    setItem: vi.fn(),
    removeItem: vi.fn(),
  },
}));

describe("Auth Signup and Fresh Stats", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("should initialize fresh user data with zero stats on signup", async () => {
    const userId = 1001;
    const freshData = {
      userId,
      streak: 0,
      xp: 0,
      rank: "Beginner",
      totalFocusHours: 0,
      completedSessions: 0,
      lastSessionDate: null,
      createdAt: new Date().toISOString(),
      sessionHistory: [],
    };

    // Verify fresh data has zero stats
    expect(freshData.streak).toBe(0);
    expect(freshData.xp).toBe(0);
    expect(freshData.completedSessions).toBe(0);
    expect(freshData.totalFocusHours).toBe(0);
    expect(freshData.rank).toBe("Beginner");
    expect(freshData.sessionHistory).toHaveLength(0);
  });

  it("should not have preloaded stats for new users", async () => {
    const userId = 1002;
    const userData = {
      userId,
      streak: 0,
      xp: 0,
      rank: "Beginner",
      totalFocusHours: 0,
      completedSessions: 0,
      lastSessionDate: null,
      createdAt: new Date().toISOString(),
      sessionHistory: [],
    };

    // Verify no preloaded data
    expect(userData.streak).not.toBeGreaterThan(0);
    expect(userData.xp).not.toBeGreaterThan(0);
    expect(userData.completedSessions).not.toBeGreaterThan(0);
  });

  it("should track session completion and update stats", async () => {
    const userId = 1003;
    let userData: any = {
      userId,
      streak: 0,
      xp: 0,
      rank: "Beginner",
      totalFocusHours: 0,
      completedSessions: 0,
      lastSessionDate: null,
      createdAt: new Date().toISOString(),
      sessionHistory: [],
    };

    // Simulate completing a 25-minute session
    const sessionDuration = 25;
    const xpReward = 50;

    userData.xp += xpReward;
    userData.totalFocusHours += sessionDuration / 60;
    userData.completedSessions += 1;
    userData.streak = 1;
    userData.lastSessionDate = new Date().toISOString() as any;
    (userData.sessionHistory as any).push({
      duration: sessionDuration,
      xpEarned: xpReward,
      completedAt: new Date().toISOString(),
    });

    // Verify stats were updated
    expect(userData.xp).toBe(50);
    expect(userData.completedSessions).toBe(1);
    expect(userData.streak).toBe(1);
    expect(userData.totalFocusHours).toBeCloseTo(25 / 60, 2);
    expect(userData.sessionHistory).toHaveLength(1);
  });

  it("should calculate rank based on XP", async () => {
    const userId = 1004;
    let userData = {
      userId,
      streak: 0,
      xp: 0,
      rank: "Beginner",
      totalFocusHours: 0,
      completedSessions: 0,
      lastSessionDate: null,
      createdAt: new Date().toISOString(),
      sessionHistory: [],
    };

    // Simulate multiple sessions to reach different ranks
    const sessions = [
      { xp: 50, duration: 25 }, // Total: 50 XP -> Beginner
      { xp: 50, duration: 25 }, // Total: 100 XP -> Beginner
      { xp: 100, duration: 45 }, // Total: 200 XP -> Beginner
      { xp: 50, duration: 25 }, // Total: 250 XP -> Focused
      { xp: 100, duration: 45 }, // Total: 350 XP -> Focused
      { xp: 150, duration: 90 }, // Total: 500 XP -> Elite
    ];

    sessions.forEach((session) => {
      userData.xp += session.xp;
      userData.totalFocusHours += session.duration / 60;
      userData.completedSessions += 1;

      // Update rank based on XP
      if (userData.xp >= 500) userData.rank = "Elite";
      else if (userData.xp >= 250) userData.rank = "Focused";
      else userData.rank = "Beginner";
    });

    expect(userData.xp).toBe(500);
    expect(userData.rank).toBe("Elite");
    expect(userData.completedSessions).toBe(6);
  });

  it("should unlock 45-min session after 3 completed sessions", async () => {
    const userId = 1005;
    let completedSessions = 0;

    // Complete 3 sessions
    for (let i = 0; i < 3; i++) {
      completedSessions += 1;
    }

    const isLevel45Unlocked = completedSessions >= 3;
    expect(isLevel45Unlocked).toBe(true);
  });

  it("should unlock 90-min session after 7-day streak", async () => {
    const userId = 1006;
    let streak = 0;

    // Build 7-day streak
    for (let i = 0; i < 7; i++) {
      streak += 1;
    }

    const isLevel90Unlocked = streak >= 7;
    expect(isLevel90Unlocked).toBe(true);
  });

  it("should track session history with timestamps", async () => {
    const userId = 1007;
    let userData: any = {
      userId,
      streak: 0,
      xp: 0,
      rank: "Beginner",
      totalFocusHours: 0,
      completedSessions: 0,
      lastSessionDate: null,
      createdAt: new Date().toISOString(),
      sessionHistory: [],
    };

    const now = new Date();
    userData.sessionHistory.push({
      duration: 25,
      xpEarned: 50,
      completedAt: now.toISOString(),
    });

    expect(userData.sessionHistory).toHaveLength(1);
    expect((userData.sessionHistory as any)[0].duration).toBe(25);
    expect((userData.sessionHistory as any)[0].xpEarned).toBe(50);
    expect((userData.sessionHistory as any)[0].completedAt).toBe(now.toISOString());
  });

  it("should handle consecutive day streak logic", async () => {
    const userId = 1008;
    let userData = {
      userId,
      streak: 2,
      xp: 100,
      rank: "Beginner",
      totalFocusHours: 1,
      completedSessions: 2,
      lastSessionDate: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(), // Yesterday
      createdAt: new Date().toISOString(),
      sessionHistory: [],
    };

    // Simulate session today (consecutive day)
    const today = new Date();
    const lastDate = new Date(userData.lastSessionDate);
    const daysDiff = Math.floor(
      (today.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24)
    );

    if (daysDiff === 1) {
      userData.streak += 1; // Increment streak
    }

    expect(userData.streak).toBe(3);
  });

  it("should reset streak if more than 1 day has passed", async () => {
    const userId = 1009;
    let userData = {
      userId,
      streak: 5,
      xp: 250,
      rank: "Focused",
      totalFocusHours: 2.5,
      completedSessions: 5,
      lastSessionDate: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(), // 3 days ago
      createdAt: new Date().toISOString(),
      sessionHistory: [],
    };

    // Simulate session today (more than 1 day has passed)
    const today = new Date();
    const lastDate = new Date(userData.lastSessionDate);
    const daysDiff = Math.floor(
      (today.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24)
    );

    if (daysDiff > 1) {
      userData.streak = 1; // Reset to 1
    }

    expect(userData.streak).toBe(1);
  });
});

/** @type {const} */
const themeColors = {
  // Mint to cyan gradient for buttons
  primary: { light: '#1DD1A1', dark: '#1DD1A1' },
  // Dark background for modern look
  background: { light: '#ffffff', dark: '#0F1419' },
  // Slightly lighter dark surface for cards
  surface: { light: '#f5f5f5', dark: '#1a1f2e' },
  // Light text on dark background
  foreground: { light: '#11181C', dark: '#FFFFFF' },
  // Muted text (secondary)
  muted: { light: '#687076', dark: '#8B92A0' },
  // Darker borders for dark theme
  border: { light: '#E5E7EB', dark: '#2d3748' },
  // Success green
  success: { light: '#22C55E', dark: '#4ADE80' },
  // Warning yellow
  warning: { light: '#F59E0B', dark: '#FBBF24' },
  // Error red
  error: { light: '#EF4444', dark: '#F87171' },
  // Cyan accent for secondary actions
  accent: { light: '#00D9FF', dark: '#00D9FF' },
};

module.exports = { themeColors };

# FocusForge - Project TODO

## Phase 1: Core Setup & Design
- [x] Create design.md with screen layouts and user flows
- [x] Set up theme colors and branding (dark mode, aggressive orange)
- [x] Generate custom app logo/icon
- [x] Update app.config.ts with app name and branding
- [x] Create todo.md (this file)

## Phase 2: Daily Missions & Focus Timer
- [x] Build Home screen with streak counter, rank display, and mission list
- [ ] Implement Daily Mission creation/editing flow
- [x] Build Focus Mode screen with full-screen timer
- [ ] Implement unbypassable focus session (cannot exit until timer completes)
- [ ] Add emergency unlock with penalty system
- [x] Create local data storage for missions using AsyncStorage
- [ ] Implement background timer for focus sessions

## Phase 3: Punishment System & Progress Tracking
- [ ] Implement streak tracking and loss on mission failure
- [ ] Build punishment system (streak loss, score drops, feature locks, reputation decrease)
- [ ] Create Progress screen with weekly graph and metrics
- [ ] Implement XP system and rank progression (Beginner → Focused → Elite)
- [ ] Build Punishment History screen to show past penalties
- [ ] Add data persistence for all metrics

## Phase 4: AI Accountability Coach (Premium)
- [ ] Design AI Coach chat interface
- [ ] Implement daily check-in prompts ("Why did you fail?")
- [ ] Build quick reply buttons for guided reflection
- [ ] Integrate with backend LLM for adaptive AI responses
- [ ] Create premium paywall for Coach feature
- [ ] Implement subscription management

## Phase 5: Notifications & App Blocking
- [ ] Set up push notification system
- [ ] Implement daily reminder notifications (9 AM)
- [ ] Add mission deadline notifications
- [ ] Implement streak loss notifications
- [ ] Research and implement app blocking for Android (priority)
- [ ] Explore iOS Screen Time API integration for app blocking
- [ ] Add "No exit mode" for premium users

## Phase 6: Settings & Premium Features
- [ ] Build Settings screen with theme toggle, notifications, account settings
- [ ] Implement premium subscription flow
- [ ] Add subscription status display
- [ ] Create data export functionality
- [ ] Add "Custom punishments" for premium users
- [ ] Implement advanced analytics for premium users

## Phase 7: Testing & Optimization
- [ ] Test all user flows end-to-end
- [ ] Verify data persistence across app restarts
- [ ] Test background timer accuracy
- [ ] Optimize animations and transitions for 60fps
- [ ] Test on both iOS and Android devices
- [ ] Performance profiling and optimization
- [ ] Accessibility review (contrast, font sizes, touch targets)

## Phase 8: Deployment & Launch
- [ ] Create app icon and splash screen
- [ ] Generate iOS and Android builds
- [ ] Submit to App Store (iOS)
- [ ] Submit to Google Play (Android)
- [ ] Create landing page/marketing materials
- [ ] Set up analytics and crash reporting

## Known Challenges
- [ ] iOS app blocking: Limited by Apple's policies; may need alternative approach
- [ ] Background timer accuracy: Ensure reliable timing even with OS restrictions
- [ ] AI Coach quality: Requires careful prompt engineering for effective feedback
- [ ] Retention: Hard accountability may lead to higher churn; need careful UX balance

## Notes
- Start with Android for app blocking feature (easier implementation)
- Prioritize core loop: Mission → Focus Session → Completion → Streak increase
- Dark mode default with high contrast for aggressive aesthetic
- All primary actions should be one-handed accessible on portrait orientation
